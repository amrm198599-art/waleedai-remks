# Waled AI — Complete AI Video Creation Platform

Waled AI (وليد AI) is a full-stack bilingual web application for creating animated cartoon videos from text prompts, scripts, and audio. It features a custom 2D keyframed cartoon animation studio, script generation, audio synthesis, and video rendering producing downloadable MP4/WebM files.

---

## 🌟 Core Features

### 1. Bilingual Localization (Arabic Default & English)
- **Arabic First**: Default language with full RTL layout, tailored typography (Tajawal font), and authentic Arabic dialogue generation.
- **English Supported**: Clean LTR layout with Plus Jakarta Sans typography.
- **Persistent Switcher**: Instant switching between Arabic and English with state preserved across sessions.
- **Independent Spoken Language**: Spoken dialogue and subtitles can be configured in Arabic or English regardless of interface language.

### 2. Mode A: Animated Cartoon Studio (2D Vector Animation Engine)
- **Reusable Rigged Characters with Consistent Identities**:
  - **Bader the Rabbit (الأرنب بدر)**: Expressive ears, carrot accessory, bouncing stride.
  - **Faris the Bear (الدب فارس)**: Friendly brown bear, honey pot, gentle giant.
  - **Maymoun the Monkey (القرد ميمون)**: Agile acrobat with curl tail and golden banana.
  - **Salma the Explorer (سلمى المستكشفة)**: Safari hat, backpack, and binoculars.
  - **Robo-Z (الروبوت زيرو)**: Retro robot with glowing antenna, emotive LED screen face, and rocket thrusters.
- **Keyframe Motion Presets**:
  - `idle`: Natural breathing bounce, blinking, ear/tail sway.
  - `walk`: Rhythmic leg stride cycle and arm swing.
  - `run`: Forward torso tilt, high-speed stride, dust puff particles.
  - `jump`: Parabolic arc with squash & stretch physics.
  - `wave`: Friendly hand waving gesture.
  - `talk`: Lip-sync mouth visemes synchronized with speech.
  - `laugh`: Torso shaking with floating musical/laugh notes.
  - `celebrate`: Cheering with arms raised and star sparkles.
  - `fall`: Comedic tumble with dizzy orbiting stars.
  - `look_left` / `look_right`: Head turn with pupil shifts.
- **Parallax Background Environments**:
  - `enchanted_forest`: Volumetric sunbeams, glowing fireflies, lush canopy.
  - `sunny_meadow`: Azure sky, animated cumulus clouds, rolling hills, wildflowers.
  - `treehouse_interior`: Cedar walls, swinging oil lantern with warm glow, bookshelf.
  - `cosmic_galaxy`: Deep purple nebula, twinkling stars, ringed planet.
  - `city_park`: Sunset promenade with street lamp and skyscraper silhouette.

### 3. Mode B: AI-Assisted Script & Storyboard Engine
- **Server-Side AI Script Generation**:
  - Integrates `@google/genai` with `gemini-3.8-flash` using structured JSON Schema.
  - Generates scene breakdowns: duration, narration, character dialogue, action instructions, camera movements, and audio cues.
- **Resilient Offline Creative Engine**:
  - Built-in rule-based screenplay generator activates automatically if the Gemini API key is unset or external quota is depleted.

### 4. Audio & Speech Synthesis
- **Sound Effects (SFX)**: Dynamic real-time Web Audio synthesis (`pop`, `boing`, `whoosh`, `cheer`, `laugh`, `footsteps`, `bell`).
- **Background Music**: Procedural synthesizer loops (`playful_adventure`, `whimsical_story`, `upbeat_groove`).
- **Speech Synthesis**: Browser SpeechSynthesis and server-side speech endpoints with custom pitch, rate, and timbre for each character.

### 5. Video Rendering Pipeline
- Synchronous frame-by-frame rendering at 30 FPS.
- Live canvas capture + Web Audio destination combined stream.
- In-browser `MediaRecorder` encoding.
- Server-side FFmpeg (`/usr/bin/ffmpeg`) transcode endpoint converting WebM to pure H.264/AAC MP4.
- High-contrast subtitles burn-in with speaker labels.
- Live progress feedback with genuine measured stages: `validating_assets` -> `synthesizing_audio` -> `rendering_frames` -> `assembling_stream` -> `finalizing`.
- Direct download button for playable `.mp4` video files.

### 6. Free-Tier Quota Policy
- **Allowance**: Up to 2 video generation jobs per rolling 24-hour period per user.
- **Enforcement**: Atomic server-side reservation prevents concurrent race conditions.
- **Transparency**: Live reset timer ("Resets in Xh Ym") displayed on the navbar and free usage panel.
- **Failure Policy**: Quota is released automatically if rendering encounters an unrecoverable failure.
- **Always Free**: Previewing, scriptwriting, and editing projects never consume quota.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 19, Vite 8, Tailwind CSS 4, Lucide Icons, Motion |
| **Backend** | Express 4, Node.js 22, tsx |
| **AI Integration** | `@google/genai` (`gemini-3.8-flash`) |
| **Media Processing** | HTML5 2D Canvas, Web Audio API, `/usr/bin/ffmpeg` |
| **Database & Auth** | Supabase PostgreSQL schema (`schema.sql`) + Local Atomic JSON Store |

---

## 🚀 Getting Started

### 1. Install Dependencies
```bash
npm install
```

### 2. Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Key configuration:
- `GEMINI_API_KEY`: (Optional) Injected automatically in Google AI Studio. If left blank, the built-in offline creative engine is used.
- `PORT`: Server port (default: `3000`).
- `DAILY_FREE_QUOTA_LIMIT`: Daily video generations allowance (default: `2`).

### 3. Run Development Server
```bash
npm run dev
```
Open `http://localhost:3000` in your browser.

### 4. Run Automated Tests
```bash
npm test
```
The test suite validates:
- User profile provisioning
- Atomic 24-hour quota allowance (2 jobs)
- Third job rejection with HTTP 429
- Failed job quota restoration
- Project persistence and scene updating
- Script generation schema conformity
- FFmpeg binary availability

### 5. Production Build
```bash
npm run build
npm start
```

---

## 📄 License & Attribution

All custom character rigs and backgrounds are licensed under the Creative Commons CC0 1.0 Universal dedication (Public Domain). For full details, see [LICENSES.md](./LICENSES.md).

---

## 🎬 AI Text-to-Video (new)

Open **"AI Text-to-Video"** in the sidebar, pick a project and a method:

| Method | Cost | What you get |
|---|---|---|
| **Free: images + motion + voice** | Free | An AI image per scene, Ken Burns motion, optional narration, assembled with FFmpeg. No character drift between scenes. |
| **Real video (fal.ai)** | Paid | A generated video clip per scene, looped/trimmed to the scene length, your narration on top. |

**Safety by default:** the paid provider is OFF until you set `PAID_VIDEO_ENABLED=true`, `FAL_KEY` and `FAL_VIDEO_MODEL` (copy the exact id from the model's page on fal.ai). A global daily budget (`FAL_DAILY_BUDGET_USD`, default $2) is checked before every job and persisted across restarts.

**Known limits (be honest with yourself before launching):**
- There is still **no user login**, so the budget cap is shared by everyone. Add authentication before exposing the paid provider publicly.
- The free image/voice URLs (`IMAGE_URL_TEMPLATE`, `TTS_URL_TEMPLATE`) point at a free third-party service. They can change, rate-limit or disappear; swap the URL in `.env` without touching code. If an image fails the scene falls back to a gradient and the job still finishes.
- Subtitles are not burned into AI videos yet (Arabic shaping needs a font + libass setup).
- Jobs are kept in memory and run one at a time; a server restart forgets running jobs.

API: `GET /api/ai-video/providers`, `POST /api/ai-video/create {projectId, provider, style}`, `GET /api/ai-video/jobs/:id`.

### 🔊 Audio, 50 stories, and saving to the phone gallery

- **No more silent videos.** Narration tries Gemini TTS (`GEMINI_API_KEY`), then `TTS_URL_TEMPLATE`, then local `espeak-ng`. Background music is generated by FFmpeg and mixed in, so the video always has sound. If no narration engine works, the result screen shows an audio warning instead of failing silently.
- **50 ready stories** (5 characters x 5 places x 2 plots) in `src/lib/stories/library.ts`; pick one in the AI Text-to-Video screen to create a project in one tap.
- **Save to gallery:** the result screen has a button that opens the phone's share sheet ("Save video" puts the MP4 in the gallery). Inside the Capacitor APK you will additionally need a media plugin for direct gallery saving.

### 🎞️ Split-screen Remix (new)

Sidebar -> **Split-screen Remix**. Pick a top and a bottom video (upload from your phone, or any video you generated in the app), choose audio (both / top / bottom / none) and length (shortest / longest with looping), then save the result to the gallery with the share sheet.

- Server: `server/video/remix.ts` (FFmpeg `vstack`, each half cropped to fill, 720x1280 H.264/AAC) and `server/video/remixRoutes.ts` (`POST /api/remix/upload`, `POST /api/remix/create`, `GET /api/remix/jobs/:id`, `GET /api/remix/:id/file`).
- Limits: uploads up to 250 MB and 300 s each, mp4/mov/webm/mkv/m4v/3gp, kept in the OS temp folder for one hour; output capped at 120 s; one remix at a time.
- Only remix videos you own or have the right to use.
