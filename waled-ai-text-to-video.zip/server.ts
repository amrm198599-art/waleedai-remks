import fs from 'fs';
import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import crypto from 'crypto';
import { db } from './server/db';
import { generateScriptWithAI, testGeminiConnection } from './server/ai';
import { convertWebmToMp4 } from './server/render';
import { aiVideoRouter } from './server/video/routes';
import { remixRouter } from './server/video/remixRoutes';
import { CHARACTER_CATALOG } from './src/lib/animation/characters';
import { BACKGROUND_CATALOG } from './src/lib/animation/backgrounds';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Body Parsers
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Raw binary parser for MP4 conversion and video upload endpoints
app.use('/api/render/convert-mp4', express.raw({ type: '*/*', limit: '100mb' }));
app.use('/api/videos/:projectId/upload', express.raw({ type: '*/*', limit: '100mb' }));

// -----------------------------------------------------------------------------
// API ROUTES
// -----------------------------------------------------------------------------

// AI video generation (free slideshow provider + optional paid fal.ai provider)
app.use('/api/ai-video', aiVideoRouter);
app.use('/api/remix', remixRouter);

// 1. Current User Profile
app.get('/api/auth/me', (req, res) => {
  const profile = db.getProfile();
  const quota = db.getQuotaStatus(profile.id);
  res.json({ profile, quota });
});

// 2. Free Quota Status (Atomic 24-hour Rolling Window Policy)
app.get('/api/quota/status', (req, res) => {
  const profile = db.getProfile();
  const quota = db.getQuotaStatus(profile.id);
  res.json(quota);
});

// 3. Projects List
app.get('/api/projects', (req, res) => {
  const profile = db.getProfile();
  const projects = db.getProjects(profile.id);
  res.json(projects);
});

// 4. Create Project
app.post('/api/projects', (req, res) => {
  const profile = db.getProfile();
  const { title, description, language, aspectRatio, videoStyle, scenes, duration } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Project title is required' });
  }

  const newProject = db.saveProject({
    id: `proj_${crypto.randomUUID()}`,
    userId: profile.id,
    title,
    description: description || '',
    language: language || 'ar',
    aspectRatio: aspectRatio || '16:9',
    videoStyle: videoStyle || 'cartoon',
    duration: duration || 15,
    scenes: scenes || [],
    status: 'draft',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  res.status(201).json(newProject);
});

// 5. Get Project by ID
app.get('/api/projects/:id', (req, res) => {
  const profile = db.getProfile();
  const project = db.getProject(req.params.id, profile.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }
  res.json(project);
});

// 6. Update Project
app.put('/api/projects/:id', (req, res) => {
  const profile = db.getProfile();
  const existing = db.getProject(req.params.id, profile.id);
  if (!existing) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const updated = db.saveProject({
    ...existing,
    ...req.body,
    id: existing.id,
    userId: existing.userId,
    updatedAt: new Date().toISOString(),
  });

  res.json(updated);
});

// 7. Delete Project
app.delete('/api/projects/:id', (req, res) => {
  const profile = db.getProfile();
  const deleted = db.deleteProject(req.params.id, profile.id);
  if (!deleted) {
    return res.status(404).json({ error: 'Project not found' });
  }
  res.json({ success: true, message: 'Project deleted successfully' });
});

// 8. Generate Script with AI / Offline Fallback
// 8.1 Test Gemini Connection Endpoint
app.get('/api/ai/test-connection', async (req, res) => {
  const result = await testGeminiConnection();
  res.json(result);
});

app.post('/api/generate/script', async (req, res) => {
  const { prompt, language = 'ar', aspectRatio = '16:9', durationSeconds = 15 } = req.body;

  if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const result = await generateScriptWithAI({
      prompt: prompt.trim(),
      language: language as any,
      aspectRatio: aspectRatio as any,
      durationSeconds: Number(durationSeconds) || 15,
    });
    res.json(result);
  } catch (error: any) {
    console.error('[API] Script generation error:', error);
    res.status(500).json({ error: 'Failed to generate script', details: error.message });
  }
});

// 9. Concurrency-Controlled Job Creation (Unlimited Daily Generations)
app.post('/api/jobs/create', (req, res) => {
  const profile = db.getProfile();
  const { projectId, idempotencyKey } = req.body;

  if (!projectId) {
    return res.status(400).json({ error: 'projectId is required' });
  }

  const project = db.getProject(projectId, profile.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const jobId = `job_${crypto.randomUUID()}`;

  // Reserve slot with concurrency check & idempotency (Unlimited daily quota)
  const reservation = db.reserveQuota(profile.id, jobId, idempotencyKey);
  if (!reservation.success) {
    return res.status(429).json({
      error: reservation.error || 'Too many concurrent video renders in progress. Please wait for an active job to finish.',
      code: 'CONCURRENT_LIMIT',
      quota: reservation.quota,
      message: 'A video generation job is already in progress. Please wait for it to complete.',
    });
  }

  // Handle idempotency reuse
  if (reservation.existingJobId) {
    const existing = db.getJob(reservation.existingJobId);
    if (existing) {
      return res.status(200).json({ job: existing, quota: reservation.quota, reused: true });
    }
  }

  const job = db.createJob({
    id: jobId,
    userId: profile.id,
    projectId,
    status: 'queued',
    progress: 0,
    idempotencyKey: idempotencyKey || `idem_${crypto.randomUUID()}`,
    logs: ['Job initiated successfully under unlimited quota.'],
    createdAt: new Date().toISOString(),
    startedAt: new Date().toISOString(),
  });

  res.status(201).json({ job, quota: reservation.quota });
});

// 10. Get Job Status
app.get('/api/jobs/:id', (req, res) => {
  const job = db.getJob(req.params.id);
  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }
  res.json(job);
});

// 11. Persistent Video Upload & MP4 Conversion
app.post(
  '/api/videos/:projectId/upload',
  express.raw({ type: '*/*', limit: '150mb' }),
  async (req, res) => {
    const profile = db.getProfile();
    const { projectId } = req.params;

    const project = db.getProject(projectId, profile.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found or unauthorized' });
    }

    try {
      const buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.from(req.body);

      if (!buffer || buffer.length === 0) {
        return res.status(400).json({ error: 'No video payload received' });
      }

      // Convert WebM to verified H.264 / AAC MP4 with faststart
      const { mp4Buffer } = await convertWebmToMp4({
        buffer,
        duration: project.duration || 15,
      });

      // Save MP4 permanently to disk
      await db.saveVideoFile(projectId, mp4Buffer);

      // Update project state with stable server URLs
      const streamUrl = `/api/videos/${projectId}/view`;
      const downloadUrl = `/api/videos/${projectId}/download`;

      db.saveProject({
        ...project,
        status: 'completed',
        renderedVideoUrl: streamUrl,
        streamUrl,
        downloadUrl,
        updatedAt: new Date().toISOString(),
      });

      // Mark user active jobs for this project as completed
      Object.values(db['data'].jobs).forEach((j) => {
        if (j.projectId === projectId && j.userId === profile.id && j.status !== 'failed') {
          db.updateJob(j.id, {
            status: 'completed',
            progress: 100,
            outputVideoUrl: streamUrl,
            completedAt: new Date().toISOString(),
          });
          db.releaseQuota(profile.id, j.id, 'completed');
        }
      });

      res.json({
        success: true,
        downloadUrl,
        streamUrl,
        fileSize: mp4Buffer.length,
        format: 'mp4',
      });
    } catch (err: any) {
      console.error('[API] Video upload/encoding error:', err);
      res.status(500).json({ error: 'Video encoding failed', details: err.message });
    }
  }
);

// 12. Video File Verification Endpoint (Check file existence, size, and readiness)
app.get('/api/videos/:projectId/status', (req, res) => {
  const profile = db.getProfile();
  const { projectId } = req.params;

  const project = db.getProject(projectId, profile.id);
  if (!project) {
    return res.status(404).json({ exists: false, error: 'Project not found or unauthorized' });
  }

  const filePath = db.getVideoFilePath(projectId);
  const exists = fs.existsSync(filePath);
  let size = 0;
  if (exists) {
    try {
      size = fs.statSync(filePath).size;
    } catch (e) {
      // Ignored
    }
  }

  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.json({
    exists,
    size,
    projectId,
    title: project.title,
    status: project.status,
    streamUrl: `/api/videos/${projectId}/view`,
    downloadUrl: `/api/videos/${projectId}/download`,
    format: 'mp4',
    duration: project.duration || 15,
    aspectRatio: project.aspectRatio || '16:9',
  });
});

// 13. Authenticated Video Direct Download (Attachment)
app.get('/api/videos/:projectId/download', (req, res) => {
  const profile = db.getProfile();
  const { projectId } = req.params;

  const project = db.getProject(projectId, profile.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found or unauthorized' });
  }

  const filePath = db.getVideoFilePath(projectId);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      error: 'Video file is not yet rendered or missing',
      code: 'VIDEO_NOT_FOUND',
      message: 'Video file not found on disk. Please render the project first.',
    });
  }

  const stat = fs.statSync(filePath);
  const cleanTitle = (project.title || 'video').trim().replace(/[\r\n\t]/g, '');
  const safeAscii = cleanTitle.replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_') || `waled_${projectId}`;
  const utf8Encoded = encodeURIComponent(`${cleanTitle}.mp4`);

  res.setHeader('Content-Type', 'video/mp4');
  res.setHeader('Content-Disposition', `attachment; filename="${safeAscii}.mp4"; filename*=UTF-8''${utf8Encoded}`);
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Accept-Ranges', 'bytes');
  res.setHeader('Cache-Control', 'private, no-transform, max-age=3600');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Content-Disposition, Accept-Ranges');

  if (req.method === 'HEAD') {
    return res.end();
  }

  const stream = fs.createReadStream(filePath);
  stream.on('error', (err) => {
    console.error('[Download Stream Error]', err);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Failed to stream video file' });
    }
  });
  stream.pipe(res);
});

// 14. Authenticated Video Inline Stream & Mobile View (HTTP 206 Partial Content)
app.get('/api/videos/:projectId/view', (req, res) => {
  const profile = db.getProfile();
  const { projectId } = req.params;

  const project = db.getProject(projectId, profile.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found or unauthorized' });
  }

  const filePath = db.getVideoFilePath(projectId);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      error: 'Video file is not yet rendered or missing',
      code: 'VIDEO_NOT_FOUND',
    });
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Content-Disposition, Accept-Ranges');

  if (req.method === 'HEAD') {
    res.setHeader('Content-Length', fileSize);
    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    return res.end();
  }

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = end - start + 1;

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': 'video/mp4',
      'Content-Disposition': 'inline',
      'Cache-Control': 'private, max-age=3600',
    });

    const fileStream = fs.createReadStream(filePath, { start, end });
    fileStream.on('error', (err) => {
      console.error('[Stream Error]', err);
      if (!res.headersSent) res.status(500).end();
    });
    fileStream.pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': fileSize,
      'Content-Type': 'video/mp4',
      'Content-Disposition': 'inline',
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'private, max-age=3600',
    });

    const fileStream = fs.createReadStream(filePath);
    fileStream.on('error', (err) => {
      console.error('[Stream Error]', err);
      if (!res.headersSent) res.status(500).end();
    });
    fileStream.pipe(res);
  }
});

// 14. Convert WebM to MP4 fallback endpoint
app.post('/api/render/convert-mp4', async (req, res) => {
  try {
    const buffer = Buffer.isBuffer(req.body) ? req.body : Buffer.from(req.body);

    if (!buffer || buffer.length === 0) {
      return res.status(400).json({ error: 'No video payload provided' });
    }

    const { mp4Buffer } = await convertWebmToMp4({
      buffer,
      duration: 15,
    });

    res.setHeader('Content-Type', 'video/mp4');
    res.setHeader('Content-Disposition', 'attachment; filename="waled_ai_cartoon.mp4"');
    res.send(mp4Buffer);
  } catch (err: any) {
    console.error('[API] FFmpeg conversion error:', err);
    res.status(500).json({ error: 'Video encoding failed', details: err.message });
  }
});

// 12. Asset Catalog Metadata (Characters, Backgrounds, Licenses)
app.get('/api/assets', (req, res) => {
  res.json({
    characters: CHARACTER_CATALOG,
    backgrounds: BACKGROUND_CATALOG,
    soundEffects: ['pop', 'boing', 'whoosh', 'cheer', 'laugh', 'footsteps', 'bell'],
    musicTracks: [
      { id: 'playful_adventure', nameAr: 'مغامرة مرحة', nameEn: 'Playful Adventure', bpm: 110 },
      { id: 'whimsical_story', nameAr: 'حكاية خيالية', nameEn: 'Whimsical Story', bpm: 96 },
      { id: 'upbeat_groove', nameAr: 'إيقاع حيوي', nameEn: 'Upbeat Groove', bpm: 120 },
    ],
    license: {
      type: 'CC0_Public_Domain',
      text: 'All character rigs and background art are custom-built for Waled AI and licensed CC0 1.0 Universal for free commercial and personal use.',
    },
  });
});

// -----------------------------------------------------------------------------
// VITE DEV SERVER / PRODUCTION STATIC SERVING
// -----------------------------------------------------------------------------
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Waled AI] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Waled AI] Fatal startup error:', err);
  process.exit(1);
});
