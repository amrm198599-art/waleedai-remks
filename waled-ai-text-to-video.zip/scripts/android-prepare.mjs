#!/usr/bin/env node
/**
 * Prepares the Capacitor Android project for a signed release build.
 *  1. If the android/ folder is incomplete (no gradlew), regenerate it with `npx cap add android`.
 *  2. Append a signing block to android/app/build.gradle (idempotent).
 * No secrets are written anywhere: the block only READS environment variables at build time.
 */
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const ANDROID = path.join(ROOT, 'android');
const GRADLE = path.join(ANDROID, 'app', 'build.gradle');
const START = '// >>> waleed-signing (managed by scripts/android-prepare.mjs) >>>';
const END = '// <<< waleed-signing <<<';

const BLOCK = `
${START}
// Signing: only active when KEYSTORE_PATH is set (CI sets it; local debug builds are unaffected).
def waleedStoreFile = System.getenv("KEYSTORE_PATH")
if (waleedStoreFile) {
    android {
        signingConfigs {
            release {
                storeFile file(waleedStoreFile)
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS") ?: "waleed"
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
        buildTypes {
            release {
                signingConfig signingConfigs.release
            }
        }
    }
}
// Version: CI passes a growing number so every build can be uploaded as an update.
def waleedVersionCode = System.getenv("ANDROID_VERSION_CODE")
if (waleedVersionCode) {
    android {
        defaultConfig {
            versionCode waleedVersionCode.toInteger()
            versionName System.getenv("ANDROID_VERSION_NAME") ?: "1.0"
        }
    }
}
${END}
`;

export function patchGradle(text) {
  if (text.includes(START)) return { text, changed: false };
  return { text: text.replace(/\s*$/, '\n') + BLOCK, changed: true };
}

function ensureAndroidProject() {
  const complete = fs.existsSync(path.join(ANDROID, 'gradlew')) && fs.existsSync(path.join(ANDROID, 'settings.gradle'));
  if (complete) return console.log('android/ project is complete.');
  console.log('android/ is missing or incomplete: regenerating with `npx cap add android` ...');
  // Never destroy anything before the new project exists: move the old folder aside first.
  const backup = path.join(ROOT, 'android.stale-backup');
  const hadOld = fs.existsSync(ANDROID);
  fs.rmSync(backup, { recursive: true, force: true });
  if (hadOld) fs.renameSync(ANDROID, backup);
  try {
    execFileSync('npx', ['cap', 'add', 'android'], { stdio: 'inherit', cwd: ROOT, shell: process.platform === 'win32' });
  } catch (err) {
    fs.rmSync(ANDROID, { recursive: true, force: true });
    if (hadOld) fs.renameSync(backup, ANDROID); // put the old folder back
    throw new Error('`npx cap add android` failed; your original android/ folder was restored. ' + err.message);
  }
  fs.rmSync(backup, { recursive: true, force: true });
}

function main() {
  ensureAndroidProject();
  if (!fs.existsSync(GRADLE)) throw new Error(`${GRADLE} not found after preparing the project`);
  const { text, changed } = patchGradle(fs.readFileSync(GRADLE, 'utf8'));
  if (changed) fs.writeFileSync(GRADLE, text);
  console.log(changed ? 'Signing block added to android/app/build.gradle' : 'Signing block already present.');
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try { main(); } catch (e) { console.error(e.message); process.exit(1); }
}
