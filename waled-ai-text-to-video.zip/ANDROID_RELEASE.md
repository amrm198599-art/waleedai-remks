# بناء APK / AAB موقّع تلقائياً (GitHub Actions)

الملفات المضافة:

| الملف | وظيفته |
|---|---|
| `.github/workflows/android-release.yml` | الـ workflow: يبني الموقع، يجهّز مشروع الأندرويد، يوقّع، ويطلّع APK و AAB |
| `scripts/android-prepare.mjs` | يعيد توليد مجلد `android/` لو ناقص، ويضيف إعدادات التوقيع لملف Gradle (بدون أي كلمات سر) |
| `capacitor.config.ts` | بيقرأ `CAP_SERVER_URL` عشان التطبيق يوصل للسيرفر |

> مجلد `android/` اللي كان في الـ zip ناقص (مفيش `gradlew` ولا `settings.gradle`)، فالـ CI بيعيد توليده بـ `npx cap add android`. لو التوليد فشل بيرجّع المجلد القديم زي ما كان.

## 1) جهّز الـ Keystore (الملف + الباسوورد + الـ alias)

الـ alias بتاعك: **waleed** (هو الافتراضي في الإعدادات).

حوّل ملف الـ keystore لنص base64:

- Linux / Mac / Termux: `base64 -w0 waleed.jks > keystore.b64.txt`
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("waleed.jks")) | Out-File keystore.b64.txt`

افتح الملف النصي وانسخ محتواه كله.

## 2) ضيف الأسرار في GitHub

الريبو → **Settings → Secrets and variables → Actions → New repository secret**:

| الاسم | القيمة |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | محتوى الملف النصي من الخطوة 1 |
| `ANDROID_KEYSTORE_PASSWORD` | باسوورد الـ keystore |
| `ANDROID_KEY_PASSWORD` | باسوورد المفتاح (غالباً نفس اللي فوق) |
| `ANDROID_KEY_ALIAS` | `waleed` (اختياري، لأنه الافتراضي) |

ومن تبويب **Variables** ضيف:

| الاسم | القيمة |
|---|---|
| `CAP_SERVER_URL` | عنوان السيرفر بتاعك على https، مثلاً `https://waleed-ai.example.com` |

**مهم:** من غير `CAP_SERVER_URL` الـ APK هيحتوي الواجهة بس، وأي حاجة بتحتاج السيرفر (التوليد، الريمكس، الحفظ) مش هتشتغل على الموبايل. السيرفر لازم يكون مستضاف على الإنترنت (Render / Railway / VPS) ومعاه FFmpeg.

## 3) شغّل البناء

- من تبويب **Actions → Android signed release → Run workflow**، أو
- ارفع tag: `git tag v1.0.0 && git push origin v1.0.0` (وبيتحط الملف كمان في Releases).

بعد ما يخلص (10–20 دقيقة تقريباً) نزّل من **Artifacts**: `Waleed-AI-x.y.z.apk` للتجربة على الموبايل، و `.aab` لرفعه على Google Play.

الـ workflow بيتأكد قبل البناء إن الباسوورد والـ alias صح، وبعد البناء بيعرض بصمة الشهادة (SHA-256) عشان تقارنها بالنسخة اللي على Play.

## 4) كل تحديث يتحسب تلقائياً
رقم النسخة (`versionCode`) = رقم تشغيل الـ workflow، فكل بناء جديد رقمه أكبر وينفع يتنزّل كتحديث.

## بناء محلي (اختياري)
```bash
npm install && npx vite build
node scripts/android-prepare.mjs && npx cap sync android
export KEYSTORE_PATH=/path/to/waleed.jks KEYSTORE_PASSWORD=... KEY_PASSWORD=... KEY_ALIAS=waleed
cd android && ./gradlew assembleRelease bundleRelease
```

## أمان (مهم)
- **متبعتش الـ keystore ولا الباسوورد في أي شات** (ولا ليا). مكانهم الوحيد: GitHub Secrets أو جهازك.
- **خد نسخة احتياطية** من ملف الـ keystore في مكانين. لو ضاع ومفيش Play App Signing، مش هتقدر تحدّث نفس التطبيق على Play.
- ملفات `*.jks` و `*.keystore` متضافة لـ `.gitignore` عشان ماتترفعش بالغلط.
- لو حصل خطأ إصدار Java في البناء، غيّر `java-version` في الـ workflow (الإصدار الحالي 21).
