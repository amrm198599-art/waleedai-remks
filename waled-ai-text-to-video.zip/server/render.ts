import { execFile } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';

export interface ConvertOptions {
  buffer: Buffer;
  duration?: number;
}

export async function convertWebmToMp4(options: ConvertOptions): Promise<{ mp4Buffer: Buffer; duration: number }> {
  const tempId = crypto.randomUUID();
  const tempDir = os.tmpdir();
  const inputPath = path.join(tempDir, `waled_in_${tempId}.webm`);
  const outputPath = path.join(tempDir, `waled_out_${tempId}.mp4`);

  try {
    // Write input WebM buffer safely
    await fs.promises.writeFile(inputPath, options.buffer);

    // Call ffmpeg directly using execFile (prevents command injection)
    await new Promise<void>((resolve, reject) => {
      const args = [
        '-y',
        '-i', inputPath,
        '-c:v', 'libx264',
        '-preset', 'veryfast',
        '-crf', '22',
        '-pix_fmt', 'yuv420p',
        '-c:a', 'aac',
        '-b:a', '128k',
        '-movflags', '+faststart',
        outputPath,
      ];

      execFile(process.env.FFMPEG_PATH || 'ffmpeg', args, { timeout: 60000 }, (error, stdout, stderr) => {
        if (error) {
          console.error('[FFmpeg] Error encoding video:', error, stderr);
          return reject(new Error(`FFmpeg encoding failed: ${error.message}`));
        }
        resolve();
      });
    });

    const mp4Buffer = await fs.promises.readFile(outputPath);
    return {
      mp4Buffer,
      duration: options.duration || 15,
    };
  } finally {
    // Safe cleanup of temporary files
    try {
      if (fs.existsSync(inputPath)) await fs.promises.unlink(inputPath);
      if (fs.existsSync(outputPath)) await fs.promises.unlink(outputPath);
    } catch (cleanErr) {
      console.warn('[FFmpeg] Error cleaning temp files:', cleanErr);
    }
  }
}
