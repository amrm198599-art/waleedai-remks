import { GoogleGenAI, Type } from '@google/genai';
import crypto from 'crypto';
import { Scene, VideoLanguage, VideoAspectRatio, CharacterId, BackgroundId, CharacterAction, FacialExpression } from '../src/types';

export interface ScriptGenerationParams {
  prompt: string;
  language: VideoLanguage;
  aspectRatio: VideoAspectRatio;
  durationSeconds: number; // 15, 30, or 60
  targetAudience?: string;
  videoStyle?: string;
}

export interface GeneratedScriptResult {
  title: string;
  scenes: Scene[];
  provider: 'gemini' | 'offline_engine';
}

const SUPPORTED_CHARACTERS: CharacterId[] = [
  'bader_rabbit',
  'faris_bear',
  'maymoun_monkey',
  'salma_explorer',
  'robo_z',
];

const SUPPORTED_BACKGROUNDS: BackgroundId[] = [
  'enchanted_forest',
  'sunny_meadow',
  'treehouse_interior',
  'cosmic_galaxy',
  'city_park',
];

export async function generateScriptWithAI(params: ScriptGenerationParams): Promise<GeneratedScriptResult> {
  const apiKey = process.env.GEMINI_API_KEY;

  if (apiKey && apiKey.trim().length > 0 && apiKey !== 'MY_GEMINI_API_KEY') {
    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const sceneCount = Math.max(2, Math.min(6, Math.round(params.durationSeconds / 5)));
      const isAr = params.language === 'ar';

      const systemInstruction = `You are Waled AI's chief screenplay writer and animation director.
You write animated cartoon scripts with consistent character identities across scenes.
Available characters:
- "bader_rabbit": Bader the Rabbit (الأرنب بدر) - fast, cheerful, loves carrots.
- "faris_bear": Faris the Bear (الدب فارس) - kind, strong, loves honey and bananas.
- "maymoun_monkey": Maymoun the Monkey (القرد ميمون) - agile, playful acrobat.
- "salma_explorer": Salma the Explorer (سلمى المستكشفة) - brave safari adventurer.
- "robo_z": Robo-Z (الروبوت زيرو) - cheerful futuristic robot.

Available backgrounds:
- "enchanted_forest": Magical woodland with fireflies.
- "sunny_meadow": Verdant hills, blue sky, wildflowers.
- "treehouse_interior": Cozy wooden room with lantern and window.
- "cosmic_galaxy": Nebula, glowing stars, ringed planet.
- "city_park": Sunset promenade with park bench and lamppost.

Available character actions:
"idle", "walk", "run", "jump", "wave", "talk", "laugh", "celebrate", "fall", "look_left", "look_right"

Available facial expressions:
"happy", "talking", "surprised", "laughing", "determined", "silly"

Available sound effects (sfx):
"pop", "boing", "whoosh", "cheer", "laugh", "footsteps", "bell", "none"

Available music tracks:
"playful_adventure", "whimsical_story", "upbeat_groove", "none"

Language requirement:
Generate ALL dialogue, narration, titles, and speaker names in ${isAr ? 'Arabic (العربية الفصحى الممتعة والمناسبة لرسوم الكرتون)' : 'English'}.
Maintain consistent character IDs throughout all scenes!`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Create a structured cartoon animation script for a ${params.durationSeconds}-second video (${sceneCount} scenes).
User Prompt: "${params.prompt}"
Language: ${params.language}`,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              scenes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    order: { type: Type.INTEGER },
                    duration: { type: Type.NUMBER },
                    narration: { type: Type.STRING },
                    dialogueText: { type: Type.STRING },
                    speakerCharacterId: { type: Type.STRING },
                    speakerName: { type: Type.STRING },
                    expression: { type: Type.STRING },
                    primaryCharacterId: { type: Type.STRING },
                    primaryAction: { type: Type.STRING },
                    secondaryCharacterId: { type: Type.STRING },
                    secondaryAction: { type: Type.STRING },
                    backgroundId: { type: Type.STRING },
                    camera: { type: Type.STRING },
                    transition: { type: Type.STRING },
                    sfx: { type: Type.STRING },
                    musicTrack: { type: Type.STRING },
                  },
                  required: ['order', 'duration', 'narration', 'primaryCharacterId', 'primaryAction', 'backgroundId'],
                },
              },
            },
            required: ['title', 'scenes'],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      if (parsed.scenes && Array.isArray(parsed.scenes) && parsed.scenes.length > 0) {
        const scenes: Scene[] = parsed.scenes.map((raw: any, idx: number) => {
          const char1Id = SUPPORTED_CHARACTERS.includes(raw.primaryCharacterId)
            ? raw.primaryCharacterId
            : 'bader_rabbit';
          const bgId = SUPPORTED_BACKGROUNDS.includes(raw.backgroundId)
            ? raw.backgroundId
            : 'enchanted_forest';

          const characters = [
            {
              characterId: char1Id,
              action: (raw.primaryAction || 'walk') as CharacterAction,
              x: 35,
              y: 82,
              scale: 1.05,
              flipX: false,
              zIndex: 1,
            },
          ];

          if (raw.secondaryCharacterId && SUPPORTED_CHARACTERS.includes(raw.secondaryCharacterId)) {
            characters.push({
              characterId: raw.secondaryCharacterId,
              action: (raw.secondaryAction || 'idle') as CharacterAction,
              x: 70,
              y: 82,
              scale: 1.15,
              flipX: true,
              zIndex: 2,
            });
          }

          const dialogue = raw.dialogueText
            ? [
                {
                  id: crypto.randomUUID(),
                  characterId: char1Id,
                  speakerName: raw.speakerName || (isAr ? 'الأرنب' : 'Rabbit'),
                  text: raw.dialogueText,
                  expression: (raw.expression || 'happy') as FacialExpression,
                },
              ]
            : [];

          return {
            id: crypto.randomUUID(),
            order: idx,
            duration: raw.duration || 5,
            narration: raw.narration || '',
            dialogue,
            characters,
            backgroundId: bgId,
            camera: raw.camera || 'static',
            transition: raw.transition || 'fade',
            sfx: raw.sfx || 'pop',
            musicTrack: raw.musicTrack || 'playful_adventure',
            subtitlesEnabled: true,
          };
        });

        return {
          title: parsed.title || (isAr ? 'قصة كرتونية جديدة' : 'New Animated Story'),
          scenes,
          provider: 'gemini',
        };
      }
    } catch (err) {
      console.warn('[AI] Gemini generation failed, falling back to local creative engine:', err);
    }
  }

  // Resilient Local Creative Script Engine (Free-first, zero dependency guarantee)
  return generateOfflineCreativeScript(params);
}

function generateOfflineCreativeScript(params: ScriptGenerationParams): GeneratedScriptResult {
  const isAr = params.language === 'ar';
  const promptLower = params.prompt.toLowerCase();

  // Detect characters in prompt
  let char1: CharacterId = 'bader_rabbit';
  let char2: CharacterId = 'faris_bear';

  if (promptLower.includes('monkey') || promptLower.includes('قرد') || promptLower.includes('ميمون')) {
    char1 = 'maymoun_monkey';
    char2 = 'bader_rabbit';
  } else if (promptLower.includes('robot') || promptLower.includes('روبوت') || promptLower.includes('فضاء')) {
    char1 = 'robo_z';
    char2 = 'salma_explorer';
  } else if (promptLower.includes('explorer') || promptLower.includes('سلمى') || promptLower.includes('سفاري')) {
    char1 = 'salma_explorer';
    char2 = 'maymoun_monkey';
  }

  // Detect background in prompt
  let bg1: BackgroundId = 'enchanted_forest';
  let bg2: BackgroundId = 'sunny_meadow';
  if (promptLower.includes('space') || promptLower.includes('galaxy') || promptLower.includes('فضاء') || promptLower.includes('كواكب')) {
    bg1 = 'cosmic_galaxy';
    bg2 = 'cosmic_galaxy';
  } else if (promptLower.includes('city') || promptLower.includes('park') || promptLower.includes('مدينة') || promptLower.includes('حديقة')) {
    bg1 = 'city_park';
    bg2 = 'city_park';
  } else if (promptLower.includes('treehouse') || promptLower.includes('بيت الشجرة') || promptLower.includes('غرفة')) {
    bg1 = 'treehouse_interior';
    bg2 = 'treehouse_interior';
  }

  const sceneDuration = 5;
  const numScenes = Math.max(2, Math.min(6, Math.floor(params.durationSeconds / sceneDuration)));

  const scenes: Scene[] = [];

  // Scene 1: Introduction
  scenes.push({
    id: crypto.randomUUID(),
    order: 0,
    duration: sceneDuration,
    narration: isAr
      ? `تبدأ حكايتنا في أجواء مليئة بالمرح والمفاجآت غير المتوقعة.`
      : `Our cartoon adventure begins with curious friends in a colorful world.`,
    dialogue: [
      {
        id: crypto.randomUUID(),
        characterId: char1,
        speakerName: isAr ? 'البطل' : 'Hero',
        text: isAr ? 'انظروا إلى هذا الاكتشاف الرائع! ما الذي ينتظرنا اليوم؟' : 'Look what I just discovered! What an exciting day!',
        expression: 'surprised',
      },
    ],
    characters: [
      {
        characterId: char1,
        action: 'walk',
        x: 35,
        y: 82,
        scale: 1.1,
        flipX: false,
        zIndex: 1,
      },
    ],
    backgroundId: bg1,
    camera: 'pan_right',
    transition: 'fade',
    sfx: 'pop',
    musicTrack: 'playful_adventure',
    subtitlesEnabled: true,
  });

  // Scene 2: The encounter & challenge
  scenes.push({
    id: crypto.randomUUID(),
    order: 1,
    duration: sceneDuration,
    narration: isAr
      ? `يلتقي الصديقان وتبدأ لحظة من المرح والمنافسة اللطيفة.`
      : `Two friends meet and a playful, humorous rivalry sparks between them.`,
    dialogue: [
      {
        id: crypto.randomUUID(),
        characterId: char2,
        speakerName: isAr ? 'الصديق' : 'Friend',
        text: isAr ? 'يا لها من فكرة ذكية! دعنا نتعاون لنكتشف السر معاً!' : 'What a brilliant idea! Let us team up and solve it together!',
        expression: 'happy',
      },
    ],
    characters: [
      {
        characterId: char1,
        action: 'wave',
        x: 30,
        y: 82,
        scale: 1.05,
        flipX: false,
        zIndex: 1,
      },
      {
        characterId: char2,
        action: 'talk',
        x: 70,
        y: 84,
        scale: 1.2,
        flipX: true,
        zIndex: 2,
      },
    ],
    backgroundId: bg1,
    camera: 'zoom_in',
    transition: 'cut',
    sfx: 'boing',
    musicTrack: 'playful_adventure',
    subtitlesEnabled: true,
  });

  // Scene 3: Climax or resolution
  if (numScenes >= 3) {
    scenes.push({
      id: crypto.randomUUID(),
      order: 2,
      duration: sceneDuration,
      narration: isAr
        ? `في النهاية، يدرك الجميع أن الصداقة والمشاركة هما الكنز الحقيقي.`
        : `In the end, everyone celebrates that friendship and sharing are the true reward.`,
      dialogue: [
        {
          id: crypto.randomUUID(),
          characterId: char1,
          speakerName: isAr ? 'الجميع' : 'Everyone',
          text: isAr ? 'يا له من يوم رائع لا يُنسى! عاشت الصداقة والمغامرة!' : 'What an unforgettable adventure! Three cheers for friendship!',
          expression: 'laughing',
        },
      ],
      characters: [
        {
          characterId: char1,
          action: 'celebrate',
          x: 40,
          y: 82,
          scale: 1.05,
          flipX: false,
          zIndex: 1,
        },
        {
          characterId: char2,
          action: 'celebrate',
          x: 65,
          y: 84,
          scale: 1.2,
          flipX: false,
          zIndex: 2,
        },
      ],
      backgroundId: bg2,
      camera: 'static',
      transition: 'fade',
      sfx: 'cheer',
      musicTrack: 'whimsical_story',
      subtitlesEnabled: true,
    });
  }

  const title = isAr
    ? `مغامرة ${params.prompt.slice(0, 30)}...`
    : `Adventure of ${params.prompt.slice(0, 30)}...`;

  return {
    title,
    scenes,
    provider: 'offline_engine',
  };
}

export async function testGeminiConnection(): Promise<{ success: boolean; model: string; message: string }> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim().length === 0 || apiKey === "MY_GEMINI_API_KEY") {
    return {
      success: false,
      model: "gemini-3.8-flash",
      message: "GEMINI_API_KEY is not configured or is using a placeholder value on the server.",
    };
  }
  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: "Ping test: respond with exactly OK",
    });
    return {
      success: true,
      model: "gemini-3.8-flash",
      message: "Gemini API connection test succeeded. Model responded successfully.",
    };
  } catch (err: any) {
    return {
      success: false,
      model: "gemini-3.8-flash",
      message: `Gemini API connection failed: ${err.message || "Unknown error"}. Please verify your API key privileges.`,
    };
  }
}
