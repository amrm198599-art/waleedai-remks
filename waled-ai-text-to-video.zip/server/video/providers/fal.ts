import path from 'path';
import { ClipResult, ProviderContext, SceneInput, VideoProvider } from '../types';
import { videoConfig } from '../config';
import { downloadFile, generateNarration } from '../media';
import { normalizeVideoClip, probeDuration } from '../ffmpeg';

const BASE = 'https://queue.fal.run';

async function falFetch(url: string, init: RequestInit = {}) {
  const res = await fetch(url, {
    ...init,
    signal: AbortSignal.timeout(30_000),
    headers: {
      Authorization: `Key ${videoConfig.falKey}`,
      'Content-Type': 'application/json',
      ...(init.headers || {}),
    },
  });
  if (!res.ok) {
    const body = (await res.text().catch(() => '')).slice(0, 300);
    throw new Error(`fal.ai HTTP ${res.status}: ${body || res.statusText}`);
  }
  return res.json() as Promise<any>;
}

function extractVideoUrl(result: any): string | null {
  return (
    result?.video?.url ||
    result?.videos?.[0]?.url ||
    result?.data?.video?.url ||
    result?.output?.video?.url ||
    null
  );
}

async function runFalModel(prompt: string, aspectRatio: string, report: ProviderContext['report']) {
  let extra: Record<string, unknown> = {};
  if (videoConfig.falExtraInput) {
    try { extra = JSON.parse(videoConfig.falExtraInput); }
    catch { throw new Error('FAL_VIDEO_INPUT_EXTRA is not valid JSON'); }
  }
  const submit = await falFetch(`${BASE}/${videoConfig.falModel}`, {
    method: 'POST',
    body: JSON.stringify({ prompt, aspect_ratio: aspectRatio, ...extra }),
  });
  const statusUrl: string = submit.status_url;
  const resultUrl: string = submit.response_url;
  if (!statusUrl || !resultUrl) throw new Error('fal.ai did not return a request to poll');

  const deadline = Date.now() + videoConfig.falJobTimeoutMs;
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, videoConfig.falPollIntervalMs));
    const st = await falFetch(statusUrl);
    if (st.status === 'COMPLETED') {
      const result = await falFetch(resultUrl);
      const url = extractVideoUrl(result);
      if (!url) throw new Error('fal.ai finished but returned no video URL for this model');
      return url;
    }
    if (st.status === 'FAILED' || st.error) throw new Error(`fal.ai generation failed: ${st.error || 'unknown'}`);
    report(-1, `fal.ai: ${st.status}${st.queue_position != null ? ` (queue ${st.queue_position})` : ''}`);
  }
  throw new Error('fal.ai generation timed out');
}

export const falProvider: VideoProvider = {
  id: 'fal',

  estimateCostUsd(scenes: SceneInput[]) {
    const seconds = scenes.reduce((s, sc) => s + Math.min(sc.duration, videoConfig.falClipSeconds), 0);
    return +(seconds * videoConfig.falCostPerSecond).toFixed(2);
  },

  async generateClip(scene: SceneInput, ctx: ProviderContext): Promise<ClipResult> {
    const n = scene.index + 1;
    const raw = path.join(ctx.workDir, `fal_${n}.mp4`);
    const audioPath = path.join(ctx.workDir, `scene_${n}`);
    const out = path.join(ctx.workDir, `clip_${n}.mp4`);

    const url = await runFalModel(scene.visualPrompt, ctx.aspectRatio, ctx.report);
    await downloadFile(url, raw, 120_000);

    const narr = await generateNarration(scene.narration, audioPath, ctx.language);
    const audio = narr ? narr.file : null;
    let duration = scene.duration;
    if (audio) duration = Math.max(duration, (await probeDuration(audio)) + 0.4);
    duration = Math.min(Math.max(duration, 2), 20);

    await normalizeVideoClip({ video: raw, audio, duration, width: ctx.width, height: ctx.height, out });
    return { file: out, hasNarration: !!audio, narrationEngine: narr?.engine };
  },
};
