/**
 * Central configuration for the AI-video subsystem.
 * Everything comes from environment variables so nothing is hard-coded.
 */
const num = (v: string | undefined, d: number) => {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : d;
};

export const videoConfig = {
  ffmpegPath: process.env.FFMPEG_PATH || 'ffmpeg',

  // ---- Free "slideshow" provider (images + motion + voice) ----
  // {prompt} {w} {h} {seed} are substituted. Verify the URL against the provider's current docs.
  imageUrlTemplate:
    process.env.IMAGE_URL_TEMPLATE ||
    'https://image.pollinations.ai/prompt/{prompt}?width={w}&height={h}&seed={seed}&nologo=true',
  // {text} is substituted. Set to "off" to disable server-side narration.
  ttsUrlTemplate:
    process.env.TTS_URL_TEMPLATE ||
    'https://text.pollinations.ai/{text}?model=openai-audio&voice=nova',
  // Narration engines are tried in this order: Gemini TTS -> TTS_URL_TEMPLATE -> local espeak-ng -> silent.
  geminiTtsModel: process.env.GEMINI_TTS_MODEL || 'gemini-2.5-flash-preview-tts',
  geminiTtsVoice: process.env.GEMINI_TTS_VOICE || 'Kore',
  // Free tier is ~3 requests/minute: keep a gap between Gemini TTS calls (set 0 on a paid plan).
  geminiTtsMinIntervalMs: Number(process.env.GEMINI_TTS_MIN_INTERVAL_MS ?? 21000),
  espeakPath: process.env.ESPEAK_PATH || 'espeak-ng',
  musicEnabled: process.env.BACKGROUND_MUSIC !== 'off',
  musicVolume: num(process.env.MUSIC_VOLUME, 0.3), // 0..1 relative to narration
  imageTimeoutMs: num(process.env.IMAGE_TIMEOUT_MS, 60_000),
  ttsTimeoutMs: num(process.env.TTS_TIMEOUT_MS, 45_000),

  // ---- Paid provider: fal.ai ----
  paidEnabled: process.env.PAID_VIDEO_ENABLED === 'true',
  falKey: process.env.FAL_KEY || '',
  // No default on purpose: pick the exact model id from fal's model page so you never pay for a guess.
  falModel: process.env.FAL_VIDEO_MODEL || '',
  falExtraInput: process.env.FAL_VIDEO_INPUT_EXTRA || '', // JSON merged into the request body
  falClipSeconds: num(process.env.FAL_CLIP_SECONDS, 5),
  falCostPerSecond: num(process.env.FAL_COST_PER_SECOND, 0.1), // USD, used only for the budget guard
  falDailyBudgetUsd: num(process.env.FAL_DAILY_BUDGET_USD, 2),
  falPollIntervalMs: num(process.env.FAL_POLL_INTERVAL_MS, 4000),
  falJobTimeoutMs: num(process.env.FAL_JOB_TIMEOUT_MS, 10 * 60_000),

  maxScenes: num(process.env.AI_VIDEO_MAX_SCENES, 12),
};

export function providerAvailability() {
  const paidReady = videoConfig.paidEnabled && !!videoConfig.falKey && !!videoConfig.falModel;
  let paidReason: string | undefined;
  if (!paidReady) {
    if (!videoConfig.paidEnabled) paidReason = 'PAID_VIDEO_ENABLED is not "true"';
    else if (!videoConfig.falKey) paidReason = 'FAL_KEY is missing';
    else paidReason = 'FAL_VIDEO_MODEL is missing';
  }
  return {
    slideshow: { available: true },
    fal: { available: paidReady, reason: paidReason, model: videoConfig.falModel || null },
  };
}
