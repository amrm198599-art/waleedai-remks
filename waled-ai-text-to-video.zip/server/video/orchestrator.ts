import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';
import { db } from '../db';
import type { Project } from '../../src/types';
import { providerAvailability, videoConfig } from './config';
import { concatClips, makeMusic, mixMusic, probeDuration } from './ffmpeg';
import { falProvider } from './providers/fal';
import { slideshowProvider } from './providers/slideshow';
import type { AiJobStatus, AiVideoJob, AiVideoProviderId, SceneInput, VideoProvider } from './types';

const PROVIDERS: Record<AiVideoProviderId, VideoProvider> = {
  slideshow: slideshowProvider,
  fal: falProvider,
};

const jobs = new Map<string, AiVideoJob>();
let runningJobId: string | null = null;

// ---------------------------------------------------------------------------
// Spend guard (paid providers). Persisted so a restart cannot reset the budget.
// There is no user authentication in this app yet, so this is a GLOBAL cap.
// ---------------------------------------------------------------------------
const SPEND_FILE = path.resolve(process.cwd(), '.data', 'ai_video_spend.json');

function readSpend(): { date: string; usd: number } {
  const today = new Date().toISOString().slice(0, 10);
  try {
    const s = JSON.parse(fs.readFileSync(SPEND_FILE, 'utf8'));
    if (s.date === today && typeof s.usd === 'number') return s;
  } catch { /* first run */ }
  return { date: today, usd: 0 };
}
function addSpend(usd: number) {
  const s = readSpend();
  s.usd = +(s.usd + usd).toFixed(4);
  fs.mkdirSync(path.dirname(SPEND_FILE), { recursive: true });
  fs.writeFileSync(SPEND_FILE, JSON.stringify(s));
}
export function spendToday() {
  return { ...readSpend(), budgetUsd: videoConfig.falDailyBudgetUsd };
}

// ---------------------------------------------------------------------------
// Prompt building
// ---------------------------------------------------------------------------
const BACKGROUNDS: Record<string, string> = {
  enchanted_forest: 'an enchanted forest with sunbeams and glowing fireflies',
  sunny_meadow: 'a sunny meadow with rolling hills and wildflowers under a blue sky',
  treehouse_interior: 'a cozy wooden treehouse interior with a warm lantern',
  cosmic_galaxy: 'outer space with a purple nebula, stars and a ringed planet',
  city_park: 'a city park at sunset with a street lamp and skyline',
};
const CHARACTERS: Record<string, string> = {
  bader_rabbit: 'a cheerful rabbit holding a carrot',
  faris_bear: 'a friendly brown bear with a honey pot',
  maymoun_monkey: 'an agile monkey with a golden banana',
  salma_explorer: 'a girl explorer with a safari hat and backpack',
  robo_z: 'a retro robot with a glowing antenna',
};
const STYLES = {
  cartoon: "colorful children's cartoon illustration, flat vector style, soft shading, no text",
  realistic: 'photorealistic, natural lighting, cinematic composition, no text, no watermark',
  cinematic: 'cinematic film still, dramatic lighting, shallow depth of field, no text, no watermark',
} as const;
export type VisualStyle = keyof typeof STYLES;

const hasArabic = (s: string) => /[\u0600-\u06FF]/.test(s);

async function translateScenesToVisualPrompts(texts: string[]): Promise<string[] | null> {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'MY_GEMINI_API_KEY' || texts.length === 0) return null;
  try {
    const ai = new GoogleGenAI({ apiKey: key });
    const res = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents:
        'For each scene text below, write ONE short English visual description (max 30 words) of what the camera ' +
        'sees: subject, action, setting. No dialogue, no text on screen. Reply with ONLY a JSON array of strings, ' +
        `same order and length (${texts.length}).\n\n` + JSON.stringify(texts),
    });
    const raw = (res.text || '').replace(/```json|```/g, '').trim();
    const arr = JSON.parse(raw);
    if (Array.isArray(arr) && arr.length === texts.length && arr.every((x) => typeof x === 'string')) return arr;
  } catch { /* fall back to heuristic prompts */ }
  return null;
}

async function planScenes(project: Project, style: VisualStyle): Promise<SceneInput[]> {
  const scenes = [...project.scenes].sort((a, b) => a.order - b.order).slice(0, videoConfig.maxScenes);
  const sources = scenes.map((s) => [s.narration, ...s.dialogue.map((d) => d.text)].filter(Boolean).join(' '));
  const needTranslation = sources.map((t) => hasArabic(t));
  const translated = needTranslation.some(Boolean)
    ? await translateScenesToVisualPrompts(sources)
    : null;

  return scenes.map((s, i) => {
    const bg = BACKGROUNDS[s.backgroundId] || 'a colorful outdoor scene';
    const chars = s.characters.map((c) => CHARACTERS[c.characterId]).filter(Boolean).join(' and ');
    const action = translated?.[i] || (hasArabic(sources[i]) ? '' : sources[i].slice(0, 200));
    const parts = [action, chars && `featuring ${chars}`, `setting: ${bg}`, STYLES[style]].filter(Boolean);
    return {
      index: i,
      duration: Math.min(Math.max(s.duration || 5, 2), 20),
      narration: s.narration || s.dialogue.map((d) => d.text).join(' '),
      visualPrompt: parts.join(', '),
    };
  });
}

// ---------------------------------------------------------------------------
// Job lifecycle
// ---------------------------------------------------------------------------
function touch(job: AiVideoJob, patch: Partial<AiVideoJob>) {
  Object.assign(job, patch, { updatedAt: new Date().toISOString() });
}
function log(job: AiVideoJob, msg: string) {
  job.logs.push(`${new Date().toISOString().slice(11, 19)} ${msg}`);
  if (job.logs.length > 80) job.logs.shift();
}

export function getAiJob(id: string) {
  return jobs.get(id) || null;
}

export function startAiVideoJob(
  project: Project,
  providerId: AiVideoProviderId,
  style: VisualStyle
): { job?: AiVideoJob; error?: string; status?: number } {
  if (!PROVIDERS[providerId]) return { error: 'Unknown provider', status: 400 };
  if (!project.scenes?.length) return { error: 'Project has no scenes', status: 400 };
  if (runningJobId) return { error: 'Another AI video job is already running. Please wait for it to finish.', status: 429 };

  const avail = providerAvailability()[providerId];
  if (!avail.available) {
    return { error: `Provider "${providerId}" is not available: ${(avail as any).reason}`, status: 503 };
  }

  const now = new Date().toISOString();
  const job: AiVideoJob = {
    id: `aivid_${crypto.randomUUID()}`,
    projectId: project.id,
    provider: providerId,
    status: 'queued',
    progress: 0,
    message: 'Queued',
    logs: [],
    createdAt: now,
    updatedAt: now,
  };
  jobs.set(job.id, job);
  runningJobId = job.id;

  void run(job, project, providerId, style).finally(() => {
    runningJobId = null;
  });
  return { job };
}

async function run(job: AiVideoJob, project: Project, providerId: AiVideoProviderId, style: VisualStyle) {
  const provider = PROVIDERS[providerId];
  const workDir = path.join(os.tmpdir(), `waled_${job.id}`);
  const setStage = (status: AiJobStatus, progress: number, message: string) => {
    touch(job, { status, progress: Math.round(progress), message });
    log(job, message);
  };

  try {
    await fs.promises.mkdir(workDir, { recursive: true });
    setStage('planning', 3, 'Planning scenes');
    const scenes = await planScenes(project, style);
    if (scenes.length === 0) throw new Error('No usable scenes');

    // Budget check BEFORE spending anything.
    const estimate = provider.estimateCostUsd(scenes);
    touch(job, { estimatedCostUsd: estimate });
    if (estimate > 0) {
      const { usd, budgetUsd } = spendToday();
      if (usd + estimate > budgetUsd) {
        throw new Error(
          `Daily paid-video budget would be exceeded (spent $${usd.toFixed(2)} of $${budgetUsd.toFixed(2)}, this job ≈ $${estimate.toFixed(2)}).`
        );
      }
    }

    const [w, h] =
      project.aspectRatio === '9:16' ? [720, 1280] : project.aspectRatio === '1:1' ? [720, 720] : [1280, 720];
    const seed = Math.abs(crypto.createHash('md5').update(project.id).digest().readInt32BE(0)) % 100000;

    const clips: string[] = [];
    let narrated = 0;
    for (const scene of scenes) {
      const base = 8 + (scene.index / scenes.length) * 80;
      setStage('generating_visuals', base, `Scene ${scene.index + 1}/${scenes.length}`);
      if (estimate > 0) addSpend(Math.min(scene.duration, videoConfig.falClipSeconds) * videoConfig.falCostPerSecond);

      const clip = await provider.generateClip(scene, {
        workDir,
        width: w,
        height: h,
        aspectRatio: project.aspectRatio,
        language: project.language,
        seed,
        report: (p, msg, st) => {
          if (st) touch(job, { status: st });
          if (p >= 0) touch(job, { progress: Math.round(p) });
          log(job, msg);
          touch(job, { message: msg });
        },
      });
      clips.push(clip.file);
      if (clip.hasNarration) narrated++;
      log(job, `Scene ${scene.index + 1} done${clip.hasNarration ? ` (narration: ${clip.narrationEngine})` : ' (no narration)'}`);
    }

    setStage('assembling', 92, 'Assembling final video');
    const joined = path.join(workDir, 'joined.mp4');
    await concatClips(clips, path.join(workDir, 'list.txt'), joined);

    let finalFile = joined;
    if (videoConfig.musicEnabled) {
      setStage('assembling', 96, 'Adding background music');
      try {
        const total = await probeDuration(joined);
        const music = path.join(workDir, 'music.m4a');
        await makeMusic(music, total || 10);
        finalFile = path.join(workDir, 'final.mp4');
        await mixMusic(joined, music, finalFile, narrated > 0 ? videoConfig.musicVolume : 1);
      } catch (e: any) {
        finalFile = joined;
        log(job, `Music skipped: ${e.message}`);
      }
    }
    const audioWarning =
      narrated === 0
        ? 'No narration could be generated (TTS unavailable). Set GEMINI_API_KEY, fix TTS_URL_TEMPLATE, or install espeak-ng.'
        : narrated < scenes.length
          ? `Narration is missing for ${scenes.length - narrated} of ${scenes.length} scenes.`
          : undefined;
    touch(job, { narratedScenes: narrated, totalScenes: scenes.length, audioWarning });
    if (audioWarning) log(job, `WARNING: ${audioWarning}`);

    const buffer = await fs.promises.readFile(finalFile);
    await db.saveVideoFile(project.id, buffer);
    const streamUrl = `/api/videos/${project.id}/view`;
    const downloadUrl = `/api/videos/${project.id}/download`;
    const fresh = db.getProject(project.id, project.userId) || project;
    db.saveProject({
      ...fresh,
      status: 'completed',
      renderedVideoUrl: streamUrl,
      streamUrl,
      downloadUrl,
      updatedAt: new Date().toISOString(),
    });

    touch(job, { status: 'completed', progress: 100, message: 'Done', streamUrl, downloadUrl });
    log(job, `Finished (${(buffer.length / 1_048_576).toFixed(1)} MB)`);
  } catch (err: any) {
    touch(job, { status: 'failed', message: 'Failed', error: String(err?.message || err) });
    log(job, `ERROR: ${job.error}`);
  } finally {
    fs.promises.rm(workDir, { recursive: true, force: true }).catch(() => {});
  }
}
