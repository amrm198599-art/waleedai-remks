import express, { Router } from 'express';
import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { db } from '../db';
import { hasAudio, remixSplitScreen, AudioMode, DurationMode } from './remix';
import { probeDuration } from './ffmpeg';

export const remixRouter = Router();

const DIR = path.join(os.tmpdir(), 'waled_remix');
fs.mkdirSync(DIR, { recursive: true });
const ALLOWED_EXT = new Set(['.mp4', '.mov', '.webm', '.mkv', '.m4v', '.3gp']);
const MAX_SOURCE_SECONDS = 300;
const uploads = new Map<string, { file: string; at: number }>();

interface RemixJob {
  id: string; status: 'running' | 'completed' | 'failed'; message: string;
  file?: string; downloadUrl?: string; streamUrl?: string; error?: string;
}
const jobs = new Map<string, RemixJob>();
let running: string | null = null;

function purgeOld() {
  const limit = Date.now() - 60 * 60_000;
  for (const [id, u] of uploads) if (u.at < limit) { fs.promises.rm(u.file, { force: true }).catch(() => {}); uploads.delete(id); }
}

// Raw upload: POST /api/remix/upload?name=clip.mp4  (body = the video file)
remixRouter.post('/upload', express.raw({ type: '*/*', limit: '250mb' }), async (req, res) => {
  purgeOld();
  const buf = req.body as Buffer;
  if (!Buffer.isBuffer(buf) || buf.length < 1000) return res.status(400).json({ error: 'Empty upload' });
  const ext = path.extname(String(req.query.name || '')).toLowerCase();
  if (!ALLOWED_EXT.has(ext)) return res.status(400).json({ error: 'Unsupported video type' });

  const id = `up_${crypto.randomUUID()}`;
  const file = path.join(DIR, `${id}${ext}`);
  await fs.promises.writeFile(file, buf);
  const duration = await probeDuration(file); // also proves it is a real, decodable video
  if (duration <= 0 || duration > MAX_SOURCE_SECONDS) {
    await fs.promises.rm(file, { force: true });
    return res.status(400).json({ error: duration <= 0 ? 'File is not a readable video' : `Video is longer than ${MAX_SOURCE_SECONDS}s` });
  }
  uploads.set(id, { file, at: Date.now() });
  res.json({ id, duration, hasAudio: await hasAudio(file) });
});

type Source = { type: 'upload' | 'project'; id: string };
function resolveSource(src: Source, userId: string): string | null {
  if (!src || typeof src.id !== 'string') return null;
  if (src.type === 'upload') return uploads.get(src.id)?.file ?? null;
  if (src.type === 'project') {
    if (!db.getProject(src.id, userId) || !db.hasVideoFile(src.id)) return null;
    return db.getVideoFilePath(src.id);
  }
  return null;
}

remixRouter.post('/create', express.json(), (req, res) => {
  const profile = db.getProfile();
  const { top, bottom, audio = 'both', duration = 'shortest' } = req.body || {};
  if (!['both', 'top', 'bottom', 'none'].includes(audio)) return res.status(400).json({ error: 'Invalid audio mode' });
  if (!['shortest', 'longest'].includes(duration)) return res.status(400).json({ error: 'Invalid duration mode' });
  const topFile = resolveSource(top, profile.id);
  const bottomFile = resolveSource(bottom, profile.id);
  if (!topFile || !bottomFile) return res.status(400).json({ error: 'Both videos are required (upload expired or project has no video)' });
  if (running) return res.status(429).json({ error: 'Another remix is running. Please wait.' });

  const job: RemixJob = { id: `remix_${crypto.randomUUID()}`, status: 'running', message: 'Mixing videos' };
  jobs.set(job.id, job);
  running = job.id;
  const out = path.join(DIR, `${job.id}.mp4`);
  remixSplitScreen({ top: topFile, bottom: bottomFile, out, audio: audio as AudioMode, duration: duration as DurationMode })
    .then(() => {
      Object.assign(job, {
        status: 'completed', message: 'Done', file: out,
        streamUrl: `/api/remix/${job.id}/file`, downloadUrl: `/api/remix/${job.id}/file?download=1`,
      });
    })
    .catch((e) => Object.assign(job, { status: 'failed', message: 'Failed', error: String(e.message || e) }))
    .finally(() => { running = null; });
  res.status(202).json({ job: { ...job, file: undefined } });
});

remixRouter.get('/jobs/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json({ ...job, file: undefined });
});

remixRouter.get('/:id/file', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job?.file || !fs.existsSync(job.file)) return res.status(404).json({ error: 'Not found' });
  res.setHeader('Content-Type', 'video/mp4');
  if (req.query.download) res.setHeader('Content-Disposition', 'attachment; filename="waled-ai-remix.mp4"');
  res.sendFile(job.file); // supports Range requests, so the <video> element can seek
});
