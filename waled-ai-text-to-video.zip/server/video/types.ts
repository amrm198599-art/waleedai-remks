export type AiVideoProviderId = 'slideshow' | 'fal';

export type AiJobStatus =
  | 'queued'
  | 'planning'
  | 'generating_visuals'
  | 'generating_audio'
  | 'assembling'
  | 'completed'
  | 'failed';

export interface AiVideoJob {
  id: string;
  projectId: string;
  provider: AiVideoProviderId;
  status: AiJobStatus;
  progress: number; // 0..100
  message: string;
  logs: string[];
  streamUrl?: string;
  downloadUrl?: string;
  error?: string;
  estimatedCostUsd?: number;
  narratedScenes?: number;
  totalScenes?: number;
  audioWarning?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SceneInput {
  index: number;
  duration: number; // seconds
  narration: string;
  /** English visual description used for image/video prompts. */
  visualPrompt: string;
}

export interface ProviderContext {
  workDir: string;
  width: number;
  height: number;
  aspectRatio: '16:9' | '9:16' | '1:1';
  language: 'ar' | 'en';
  seed: number;
  report: (progress: number, message: string, status?: AiJobStatus) => void;
}

export interface ClipResult {
  /** Normalised mp4 (h264/yuv420p/30fps/aac) of exactly scene.duration seconds. */
  file: string;
  hasNarration: boolean;
  narrationEngine?: string;
}

export interface VideoProvider {
  id: AiVideoProviderId;
  estimateCostUsd(scenes: SceneInput[]): number;
  generateClip(scene: SceneInput, ctx: ProviderContext): Promise<ClipResult>;
}
