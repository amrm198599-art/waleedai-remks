import { spawn } from 'child_process';
import { videoConfig } from './config';

export interface RunResult {
  stderr: string;
}

/** Runs ffmpeg with an argument array (no shell, so no injection). */
export function runFfmpeg(args: string[], timeoutMs = 180_000): Promise<RunResult> {
  return new Promise((resolve, reject) => {
    const child = spawn(videoConfig.ffmpegPath, ['-hide_banner', '-y', ...args], {
      stdio: ['ignore', 'ignore', 'pipe'],
    });
    let stderr = '';
    child.stderr.on('data', (d) => {
      stderr += d.toString();
      if (stderr.length > 20_000) stderr = stderr.slice(-10_000);
    });
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error(`ffmpeg timed out after ${timeoutMs}ms`));
    }, timeoutMs);
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(new Error(`Could not start ffmpeg ("${videoConfig.ffmpegPath}"): ${err.message}`));
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve({ stderr });
      else reject(new Error(`ffmpeg exited with code ${code}: ${stderr.slice(-600)}`));
    });
  });
}

/** Reads a media file's duration in seconds (0 if unreadable). */
export async function probeDuration(file: string): Promise<number> {
  try {
    // ffmpeg exits non-zero when there is no output file, but still prints the duration.
    await runFfmpeg(['-i', file], 20_000);
  } catch (e: any) {
    const m = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(String(e.message));
    if (m) return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
  }
  return 0;
}

const PALETTES: Array<[string, string]> = [
  ['0x1b2a6b', '0x7b3fa0'],
  ['0x0f766e', '0x84cc16'],
  ['0xb45309', '0xfacc15'],
  ['0x9d174d', '0xf97316'],
  ['0x1d4ed8', '0x22d3ee'],
];

/** Gradient placeholder used when no image could be generated. */
export async function makeGradientImage(out: string, w: number, h: number, seed: number) {
  const [c0, c1] = PALETTES[Math.abs(seed) % PALETTES.length];
  await runFfmpeg([
    '-f', 'lavfi',
    '-i', `gradients=s=${w}x${h}:c0=${c0}:c1=${c1}:x0=0:y0=0:x1=${w}:y1=${h}:d=1`,
    '-frames:v', '1',
    out,
  ], 30_000);
}

const COMMON_OUT = [
  '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-r', '30',
  '-c:a', 'aac', '-b:a', '128k', '-ar', '44100', '-ac', '2',
  '-movflags', '+faststart',
];

function audioArgs(audioFile: string | null, duration: number) {
  // Always produce an audio stream so every clip is concat-compatible.
  if (audioFile) {
    return {
      input: ['-i', audioFile],
      filter: `aresample=44100,apad,atrim=0:${duration.toFixed(3)},asetpts=N/SR/TB`,
    };
  }
  return {
    input: ['-f', 'lavfi', '-t', duration.toFixed(3), '-i', 'anullsrc=r=44100:cl=stereo'],
    filter: 'anull',
  };
}

/** Turns a still image into a gently moving clip (Ken Burns style). */
export async function stillToClip(opts: {
  image: string;
  audio: string | null;
  duration: number;
  width: number;
  height: number;
  seed: number;
  out: string;
}) {
  const { image, audio, duration, width, height, seed, out } = opts;
  const fps = 30;
  const frames = Math.max(1, Math.round(duration * fps));
  const mode = Math.abs(seed) % 4;
  const step = (0.22 / frames).toFixed(6);
  // Work on an oversized frame so the motion stays smooth (zoompan is integer-pixel based).
  const bw = width * 2;
  const bh = height * 2;
  let z: string, x: string, y: string;
  switch (mode) {
    case 0: // slow zoom in, centred
      z = `min(1+${step}*on,1.22)`; x = 'iw/2-(iw/zoom/2)'; y = 'ih/2-(ih/zoom/2)'; break;
    case 1: // slow zoom out
      z = `max(1.22-${step}*on,1.0)`; x = 'iw/2-(iw/zoom/2)'; y = 'ih/2-(ih/zoom/2)'; break;
    case 2: // zoom + pan left to right
      z = '1.18'; x = `(iw-iw/zoom)*on/${frames}`; y = 'ih/2-(ih/zoom/2)'; break;
    default: // zoom + pan right to left
      z = '1.18'; x = `(iw-iw/zoom)*(1-on/${frames})`; y = 'ih/2-(ih/zoom/2)'; break;
  }
  const fade = Math.min(0.35, duration / 4).toFixed(2);
  const vf =
    `scale=${bw}:${bh}:force_original_aspect_ratio=increase,crop=${bw}:${bh},` +
    `zoompan=z='${z}':x='${x}':y='${y}':d=${frames}:s=${width}x${height}:fps=${fps},` +
    `fade=t=in:st=0:d=${fade},fade=t=out:st=${(duration - Number(fade)).toFixed(2)}:d=${fade},format=yuv420p`;
  const a = audioArgs(audio, duration);
  await runFfmpeg([
    '-i', image, ...a.input,
    '-filter_complex', `[0:v]${vf}[v];[1:a]${a.filter}[a]`,
    '-map', '[v]', '-map', '[a]',
    '-t', duration.toFixed(3),
    ...COMMON_OUT, out,
  ]);
}

/** Fits any generated video clip to the target size/length and attaches our own audio. */
export async function normalizeVideoClip(opts: {
  video: string;
  audio: string | null;
  duration: number;
  width: number;
  height: number;
  out: string;
}) {
  const { video, audio, duration, width, height, out } = opts;
  const fade = Math.min(0.35, duration / 4).toFixed(2);
  const vf =
    `scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},` +
    `fps=30,fade=t=in:st=0:d=${fade},fade=t=out:st=${(duration - Number(fade)).toFixed(2)}:d=${fade},format=yuv420p`;
  const a = audioArgs(audio, duration);
  await runFfmpeg([
    '-stream_loop', '-1', '-i', video, ...a.input,
    '-filter_complex', `[0:v]${vf}[v];[1:a]${a.filter}[a]`,
    '-map', '[v]', '-map', '[a]',
    '-t', duration.toFixed(3),
    ...COMMON_OUT, out,
  ]);
}

/** Joins identical-format clips into the final mp4. */
export async function concatClips(files: string[], listFile: string, out: string) {
  const fs = await import('fs');
  const body = files.map((f) => `file '${f.replace(/'/g, "'\\''")}'`).join('\n');
  await fs.promises.writeFile(listFile, body);
  await runFfmpeg(['-f', 'concat', '-safe', '0', '-i', listFile, '-c', 'copy', '-movflags', '+faststart', out]);
}

/** Soft chord-pad background music (C - Am - F - G), generated by ffmpeg itself: no files, no licences. */
export async function makeMusic(out: string, duration: number) {
  const chords = [
    [261.63, 329.63, 392.0],
    [220.0, 261.63, 329.63],
    [174.61, 220.0, 261.63],
    [196.0, 246.94, 293.66],
  ];
  const tone = (i: number) =>
    chords[i].map((f) => `sin(2*PI*${f}*t)+0.5*sin(4*PI*${f}*t)`).join('+');
  const expr =
    `0.25*(if(lt(mod(t,16),4),${tone(0)},if(lt(mod(t,16),8),${tone(1)},if(lt(mod(t,16),12),${tone(2)},${tone(3)}))))` +
    `*(0.75+0.25*sin(2*PI*0.25*t))`;
  await runFfmpeg([
    '-f', 'lavfi', '-i', `aevalsrc='${expr}':s=44100:d=${duration.toFixed(2)}`,
    '-af', `lowpass=f=1400,aecho=0.8:0.6:350:0.25,afade=t=in:d=1.5,afade=t=out:st=${Math.max(0, duration - 2).toFixed(2)}:d=2`,
    '-ac', '2', '-c:a', 'aac', '-b:a', '128k', out,
  ], 60_000);
}

/** Mixes the music under the video's existing audio (narration). Video stream is copied untouched. */
export async function mixMusic(video: string, music: string, out: string, musicVolume: number) {
  await runFfmpeg([
    '-i', video, '-i', music,
    '-filter_complex',
    `[1:a]volume=${musicVolume}[m];[0:a][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]`,
    '-map', '0:v', '-map', '[a]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', out,
  ], 120_000);
}

/** Converts raw 16-bit mono PCM (what Gemini TTS returns) into a wav file. */
export async function pcmToWav(pcm: string, out: string, sampleRate = 24000) {
  await runFfmpeg(['-f', 's16le', '-ar', String(sampleRate), '-ac', '1', '-i', pcm, out], 30_000);
}
