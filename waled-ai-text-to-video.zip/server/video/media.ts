import fs from 'fs';
import { execFile } from 'child_process';
import { GoogleGenAI } from '@google/genai';
import { videoConfig } from './config';
import { makeGradientImage, pcmToWav, probeDuration } from './ffmpeg';
import { RateGate, cacheGet, cacheKey, cachePut, isDailyQuotaError, isRateLimitError } from './ttsGuard';

const ttsGate = new RateGate(videoConfig.geminiTtsMinIntervalMs);
let geminiDailyExhausted = '';  // UTC date when the daily quota ran out; skip Gemini for the rest of that day
const today = () => new Date().toISOString().slice(0, 10);

async function download(url: string, out: string, timeoutMs: number, headers?: Record<string, string>) {
  const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs), headers });
  if (!res.ok) throw new Error(`HTTP ${res.status} from ${new URL(url).host}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 1000) throw new Error('Downloaded file is suspiciously small');
  await fs.promises.writeFile(out, buf);
  return { contentType: res.headers.get('content-type') || '' };
}

export const downloadFile = download;

/**
 * Generates an image from a prompt. Never throws: on any failure it falls back to a
 * gradient so a video can still be produced. Returns whether the image is real.
 */
export async function generateSceneImage(
  prompt: string, out: string, w: number, h: number, seed: number
): Promise<{ real: boolean; error?: string }> {
  try {
    const url = videoConfig.imageUrlTemplate
      .replace('{prompt}', encodeURIComponent(prompt.slice(0, 700)))
      .replace('{w}', String(w))
      .replace('{h}', String(h))
      .replace('{seed}', String(seed));
    const { contentType } = await download(url, out, videoConfig.imageTimeoutMs);
    if (contentType && !contentType.startsWith('image/')) throw new Error(`Unexpected content-type ${contentType}`);
    return { real: true };
  } catch (e: any) {
    await makeGradientImage(out, w, h, seed);
    return { real: false, error: e.message };
  }
}

async function geminiTts(text: string, outBase: string): Promise<string | null> {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'MY_GEMINI_API_KEY') return null;
  if (geminiDailyExhausted === today()) return null;

  const wav = `${outBase}.wav`;
  const ck = cacheKey(text, videoConfig.geminiTtsVoice, videoConfig.geminiTtsModel);
  const cached = cacheGet(ck);
  if (cached) { await fs.promises.copyFile(cached, wav); return wav; }

  const ai = new GoogleGenAI({ apiKey: key });
  const call = async () => {
    const res: any = await ai.models.generateContent({
      model: videoConfig.geminiTtsModel,
      contents: [{ parts: [{ text: `Read this aloud warmly, like a children's storyteller: ${text}` }] }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: videoConfig.geminiTtsVoice } } },
      },
    });
    const b64 = res?.candidates?.[0]?.content?.parts?.find((p: any) => p?.inlineData?.data)?.inlineData?.data;
    if (!b64) throw new Error('Gemini TTS returned no audio');
    return b64 as string;
  };

  let b64: string;
  try {
    b64 = await ttsGate.run(call);
  } catch (e: any) {
    if (!isRateLimitError(e)) throw e;
    if (isDailyQuotaError(e)) { geminiDailyExhausted = today(); throw e; }
    await new Promise((r) => setTimeout(r, 30_000)); // per-minute limit: wait once, then retry
    b64 = await ttsGate.run(call);
  }
  const pcm = `${outBase}.pcm`;
  await fs.promises.writeFile(pcm, Buffer.from(b64, 'base64'));
  await pcmToWav(pcm, wav, 24000);
  await fs.promises.unlink(pcm).catch(() => {});
  await cachePut(ck, wav).catch(() => {});
  return wav;
}

async function urlTts(text: string, outBase: string): Promise<string | null> {
  const tpl = videoConfig.ttsUrlTemplate;
  if (tpl === 'off') return null;
  const out = `${outBase}.mp3`;
  const url = tpl.replace('{text}', encodeURIComponent(text.slice(0, 900)));
  const { contentType } = await download(url, out, videoConfig.ttsTimeoutMs);
  if (contentType && !/audio|octet-stream/.test(contentType)) throw new Error(`Unexpected content-type ${contentType}`);
  return out;
}

function espeakTts(text: string, outBase: string, lang: 'ar' | 'en'): Promise<string | null> {
  const out = `${outBase}.wav`;
  return new Promise((resolve, reject) => {
    execFile(videoConfig.espeakPath, ['-v', lang === 'ar' ? 'ar' : 'en-us', '-s', '150', '-w', out, text.slice(0, 900)],
      { timeout: 30_000 }, (err) => (err ? reject(err) : resolve(out)));
  });
}

/**
 * Best-effort narration. Tries each engine in turn and validates the audio.
 * Returns { file, engine } or null if every engine failed (the video is then music-only).
 */
export async function generateNarration(
  text: string, outBase: string, lang: 'ar' | 'en' = 'ar'
): Promise<{ file: string; engine: string } | null> {
  if (!text.trim()) return null;
  const engines: Array<[string, () => Promise<string | null>]> = [
    ['gemini', () => geminiTts(text, outBase)],
    ['url', () => urlTts(text, outBase)],
    ['espeak', () => espeakTts(text, outBase, lang)],
  ];
  for (const [name, fn] of engines) {
    try {
      const file = await fn();
      if (file && (await probeDuration(file)) > 0) return { file, engine: name };
    } catch { /* try next engine */ }
  }
  return null;
}
