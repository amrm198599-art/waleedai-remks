import React, { useRef, useEffect } from 'react';
import { CharacterId, CharacterAction, FacialExpression, BackgroundId } from '../../types';
import { renderCharacterRig } from '../../lib/animation/characters';
import { renderBackground } from '../../lib/animation/backgrounds';

interface CharacterCanvasProps {
  characterId: CharacterId;
  action: CharacterAction;
  expression?: FacialExpression;
  backgroundId?: BackgroundId;
  width?: number;
  height?: number;
  scale?: number;
  flipX?: boolean;
  className?: string;
}

export const CharacterCanvas: React.FC<CharacterCanvasProps> = ({
  characterId,
  action,
  expression = 'happy',
  backgroundId,
  width = 300,
  height = 300,
  scale = 1.3,
  flipX = false,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let startTime = performance.now();

    const render = (currentTime: number) => {
      const elapsedSeconds = (currentTime - startTime) / 1000;

      ctx.clearRect(0, 0, width, height);

      // Render background if specified, or a clean modern transparent studio backdrop
      if (backgroundId) {
        renderBackground(ctx, backgroundId, width, height, elapsedSeconds, 'static');
      } else {
        // Gradient studio circle floor shadow
        const shadowGrad = ctx.createRadialGradient(
          width / 2,
          height * 0.84,
          5,
          width / 2,
          height * 0.84,
          width * 0.35
        );
        shadowGrad.addColorStop(0, 'rgba(0, 0, 0, 0.45)');
        shadowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = shadowGrad;
        ctx.beginPath();
        ctx.ellipse(width / 2, height * 0.84, width * 0.3, height * 0.08, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Render Character Rig
      renderCharacterRig(
        ctx,
        characterId,
        action,
        expression,
        elapsedSeconds,
        width / 2,
        height * 0.82,
        scale,
        flipX
      );

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [characterId, action, expression, backgroundId, width, height, scale, flipX]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className={`rounded-2xl transition-all ${className}`}
    />
  );
};
