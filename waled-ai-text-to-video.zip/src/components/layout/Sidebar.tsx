import React from 'react';
import { useLocalization } from '../../lib/localization';
import { QuotaStatus } from '../../types';
import {
  LayoutDashboard,
  Video,
  FolderKanban,
  Sparkles,
  SlidersHorizontal,
  FolderOpen,
  Download,
  Settings,
  Flame,
  Clock,
  CheckCircle2,
  X,
  FileText,
  Mic,
  Image as ImageIcon,
  Wand2,
  Film,
  Layers,
} from 'lucide-react';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  quota: QuotaStatus | null;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onNavigate,
  quota,
  isOpenMobile,
  onCloseMobile,
}) => {
  const { language, t, isRTL } = useLocalization();

  const navItems = [
    { id: 'dashboard', label: t('nav.dashboard'), icon: LayoutDashboard },
    { id: 'create', label: t('nav.create_video'), icon: Video, badge: 'AI' },
    { id: 'projects', label: t('nav.my_projects'), icon: FolderKanban },
    { id: 'aivideo', label: language === 'ar' ? 'نص إلى فيديو (AI)' : 'AI Text-to-Video', icon: Film, badge: 'NEW' },
    { id: 'remix', label: language === 'ar' ? 'ريمكس شاشة مقسومة' : 'Split-screen Remix', icon: Layers, badge: 'NEW' },
    { id: 'studio', label: t('nav.animation_studio'), icon: Sparkles, highlight: true },
    { id: 'editor', label: t('nav.video_editor'), icon: SlidersHorizontal },
    { id: 'media', label: t('nav.media_library'), icon: FolderOpen },
    { id: 'exports', label: t('nav.exports'), icon: Download },
    { id: 'settings', label: t('nav.settings'), icon: Settings },
  ];

  const aiTools = [
    { id: 'create', label: t('ai_tools.text_to_story'), icon: FileText, available: true },
    { id: 'create', label: t('ai_tools.script_to_video'), icon: Video, available: true },
    { id: 'studio', label: t('ai_tools.voice_to_video'), icon: Mic, available: true },
    { id: 'studio', label: t('ai_tools.ai_motion'), icon: Wand2, available: true },
    { id: 'media', label: t('ai_tools.text_to_image'), icon: ImageIcon, available: true },
  ];

  const formatResetTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  };

  const handleSelect = (viewId: string) => {
    onNavigate(viewId);
    onCloseMobile();
  };

  const sidebarContent = (
    <div className="flex flex-col h-full justify-between p-4 overflow-y-auto">
      <div className="space-y-6">
        {/* Main Navigation */}
        <div>
          <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-purple-300/60 mb-2">
            {language === 'ar' ? 'التنقل الرئيسي' : 'Navigation'}
          </p>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-semibold transition ${
                    isActive
                      ? 'bg-waled-gradient text-white shadow-md shadow-purple-600/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-purple-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      {item.badge}
                    </span>
                  )}
                  {item.highlight && !isActive && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* AI Tools Section */}
        <div>
          <p className="px-3 text-[11px] font-bold uppercase tracking-wider text-purple-300/60 mb-2">
            {t('ai_tools.title')}
          </p>
          <div className="space-y-1">
            {aiTools.map((tool, idx) => {
              const ToolIcon = tool.icon;
              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(tool.id)}
                  className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-900/40 transition"
                >
                  <div className="flex items-center gap-2.5">
                    <ToolIcon className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{tool.label}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400/90 font-mono">
                    {language === 'ar' ? 'نشط' : 'Active'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Free Usage & Quota Panel */}
      {/* Unlimited Usage & Concurrency Panel */}
      <div className="pt-4 border-t border-purple-500/20 mt-4">
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-purple-950/40 to-slate-900/70 border border-purple-500/30 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === 'ar' ? 'الرصيد: غير محدود ♾️' : 'Credits: Unlimited ♾️'}</span>
            </span>
          </div>

          <div className="text-[11px] text-slate-300 space-y-1">
            <div className="flex items-center justify-between">
              <span>{language === 'ar' ? 'الحد اليومي' : 'Daily Limit'}:</span>
              <span className="text-cyan-300 font-bold font-mono">
                {language === 'ar' ? 'غير محدود ♾️' : 'Unlimited ♾️'}
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>{language === 'ar' ? 'المعالجة المتزامنة' : 'Concurrent Renders'}:</span>
              <span className="text-purple-300 font-mono">
                {quota ? `${quota.activeJobs} / ${quota.maxConcurrentJobs || 2}` : '0 / 2'}
              </span>
            </div>
          </div>

          <div className="pt-1.5 border-t border-purple-500/10 flex items-center gap-1.5 text-[10px] text-purple-300/80">
            <CheckCircle2 className="w-3 h-3 text-emerald-400 flex-shrink-0" />
            <span>{language === 'ar' ? 'توليد وتعديل وتصدير غير محدود' : 'Unlimited video creation & exports'}</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-64 h-[calc(100vh-61px)] sticky top-[61px] border-r rtl:border-r-0 rtl:border-l border-purple-500/20 bg-slate-950/70 glass-panel">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isOpenMobile && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
            onClick={onCloseMobile}
          />
          <div
            className={`relative w-72 max-w-[80vw] h-full bg-slate-950 border-r rtl:border-r-0 rtl:border-l border-purple-500/30 z-10 shadow-2xl ${
              isRTL ? 'mr-0' : 'ml-0'
            }`}
          >
            <div className="p-4 border-b border-purple-500/20 flex items-center justify-between">
              <span className="text-sm font-extrabold text-white">
                {language === 'ar' ? 'قائمة وليد AI' : 'Waled AI Menu'}
              </span>
              <button
                onClick={onCloseMobile}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
