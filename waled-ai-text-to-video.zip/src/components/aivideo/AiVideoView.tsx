import React, { useEffect, useRef, useState } from 'react';
import { Film, Loader2, Download, AlertTriangle, Sparkles, Wallet, Smartphone, BookOpen } from 'lucide-react';
import { STORIES } from '../../lib/stories/library';
import { useLocalization } from '../../lib/localization';
import { Project } from '../../types';

type ProviderId = 'slideshow' | 'fal';
type Style = 'cartoon' | 'realistic' | 'cinematic';

interface Providers {
  providers: Record<ProviderId, { available: boolean; reason?: string; model?: string | null }>;
  spend: { usd: number; budgetUsd: number };
}
interface Job {
  id: string;
  status: string;
  progress: number;
  message: string;
  logs: string[];
  streamUrl?: string;
  downloadUrl?: string;
  error?: string;
  estimatedCostUsd?: number;
  audioWarning?: string;
  narratedScenes?: number;
  totalScenes?: number;
}

const TXT = {
  ar: {
    title: 'نص إلى فيديو بالذكاء الاصطناعي',
    sub: 'حوّل مشروعك إلى فيديو حقيقي: صور مولّدة بالذكاء الاصطناعي مع حركة وتعليق صوتي.',
    project: 'المشروع',
    pick: 'اختر مشروعاً',
    provider: 'طريقة التوليد',
    free: 'مجاني: صور + حركة + صوت',
    paid: 'فيديو حقيقي (fal.ai) — مدفوع',
    unavailable: 'غير متاح',
    style: 'الأسلوب البصري',
    cartoon: 'كرتون',
    realistic: 'واقعي',
    cinematic: 'سينمائي',
    start: 'ابدأ التوليد',
    working: 'جارٍ التوليد...',
    done: 'الفيديو جاهز',
    download: 'تحميل MP4',
    budget: 'ميزانية اليوم للفيديو المدفوع',
    cost: 'التكلفة التقديرية',
    noProjects: 'مفيش مشاريع لسه. أنشئ مشروعاً أولاً من "إنشاء فيديو جديد".',
    note: 'ملاحظة: التوليد المجاني يعتمد على خدمات خارجية وقد تتأخر أو تفشل؛ في هذه الحالة يستخدم التطبيق خلفية بديلة ويكمل.',
    logs: 'السجل',
    stories: 'قصة جاهزة (50 قصة)',
    makeStory: 'أنشئ مشروعاً من القصة',
    save: 'حفظ في معرض الهاتف',
    saveHint: 'على الهاتف: اختر «حفظ الفيديو» من قائمة المشاركة.',
    saving: 'جارٍ التجهيز...',
    audioWarn: 'تنبيه الصوت',
    narrated: 'مشاهد بتعليق صوتي',
  },
  en: {
    title: 'AI Text-to-Video',
    sub: 'Turn your project into a real video: AI-generated visuals with motion and narration.',
    project: 'Project',
    pick: 'Choose a project',
    provider: 'Generation method',
    free: 'Free: images + motion + voice',
    paid: 'Real video (fal.ai) — paid',
    unavailable: 'Unavailable',
    style: 'Visual style',
    cartoon: 'Cartoon',
    realistic: 'Realistic',
    cinematic: 'Cinematic',
    start: 'Start generating',
    working: 'Generating...',
    done: 'Your video is ready',
    download: 'Download MP4',
    budget: "Today's paid-video budget",
    cost: 'Estimated cost',
    noProjects: 'No projects yet. Create one first from "Create new video".',
    note: 'Note: free generation relies on external services that may be slow or fail; when that happens the app uses a fallback background and carries on.',
    logs: 'Log',
    stories: 'Ready-made story (50)',
    makeStory: 'Create project from story',
    save: 'Save to phone gallery',
    saveHint: 'On a phone: choose "Save video" in the share sheet.',
    saving: 'Preparing...',
    audioWarn: 'Audio notice',
    narrated: 'Scenes with narration',
  },
} as const;

export const AiVideoView: React.FC<{ projects: Project[]; onProjectCreated?: (p: Project) => void }> = ({ projects, onProjectCreated }) => {
  const { language } = useLocalization();
  const L = TXT[language];
  const [info, setInfo] = useState<Providers | null>(null);
  const [projectId, setProjectId] = useState('');
  const [provider, setProvider] = useState<ProviderId>('slideshow');
  const [style, setStyle] = useState<Style>('cartoon');
  const [job, setJob] = useState<Job | null>(null);
  const [error, setError] = useState('');
  const timer = useRef<number | null>(null);
  const [storyId, setStoryId] = useState('');
  const [saving, setSaving] = useState(false);

  const makeFromStory = async () => {
    const st = STORIES.find((x) => x.id === storyId);
    if (!st) return;
    setError('');
    try {
      const r = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: st.title, description: st.title, language: 'ar', aspectRatio: '16:9', videoStyle: 'cartoon',
          duration: st.scenes.reduce((a, x) => a + x.duration, 0), scenes: st.scenes,
        }),
      });
      const proj = await r.json();
      if (!r.ok) throw new Error(proj.error || 'Request failed');
      onProjectCreated?.(proj);
      setProjectId(proj.id);
    } catch (e: any) { setError(e.message); }
  };

  // Share sheet lets phones save the file straight to the gallery; falls back to a normal download.
  const saveToGallery = async (url: string) => {
    setSaving(true);
    try {
      const blob = await (await fetch(url)).blob();
      const file = new File([blob], 'waled-ai-video.mp4', { type: 'video/mp4' });
      const nav: any = navigator;
      if (nav.canShare && nav.canShare({ files: [file] })) {
        await nav.share({ files: [file], title: 'Waled AI' });
      } else {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob); a.download = file.name; a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 10000);
      }
    } catch (e: any) {
      if (e?.name !== 'AbortError') setError(e.message || 'Save failed');
    } finally { setSaving(false); }
  };

  useEffect(() => {
    fetch('/api/ai-video/providers').then((r) => r.json()).then(setInfo).catch(() => {});
    return () => { if (timer.current) window.clearInterval(timer.current); };
  }, []);

  const running = !!job && !['completed', 'failed'].includes(job.status);

  const poll = (id: string) => {
    if (timer.current) window.clearInterval(timer.current);
    timer.current = window.setInterval(async () => {
      try {
        const r = await fetch(`/api/ai-video/jobs/${id}`);
        if (!r.ok) throw new Error('lost job');
        const j: Job = await r.json();
        setJob(j);
        if (j.status === 'completed' || j.status === 'failed') {
          if (timer.current) window.clearInterval(timer.current);
          fetch('/api/ai-video/providers').then((x) => x.json()).then(setInfo).catch(() => {});
        }
      } catch {
        if (timer.current) window.clearInterval(timer.current);
        setError('Lost connection to the job');
      }
    }, 2500);
  };

  const start = async () => {
    setError('');
    setJob(null);
    try {
      const r = await fetch('/api/ai-video/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, provider, style }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Request failed');
      setJob(data.job);
      poll(data.job.id);
    } catch (e: any) {
      setError(e.message);
    }
  };

  const paidOk = info?.providers.fal.available;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2"><Film className="w-6 h-6 text-purple-400" />{L.title}</h1>
        <p className="text-slate-400 mt-1 text-sm">{L.sub}</p>
      </div>

      {projects.length === 0 ? (
        <div className="rounded-xl border border-slate-700 p-6 text-slate-300">{L.noProjects}</div>
      ) : (
        <div className="rounded-xl border border-slate-700 bg-slate-900/50 p-5 space-y-5">
          <div className="space-y-2">
            <span className="text-sm text-slate-300 flex items-center gap-2"><BookOpen className="w-4 h-4" />{L.stories}</span>
            <div className="flex gap-2">
              <select value={storyId} onChange={(e) => setStoryId(e.target.value)} className="flex-1 min-w-0 rounded-lg bg-slate-800 border border-slate-600 p-3">
                <option value="">{L.pick}</option>
                {STORIES.map((st) => <option key={st.id} value={st.id}>{st.title}</option>)}
              </select>
              <button onClick={makeFromStory} disabled={!storyId} className="rounded-lg border border-slate-600 px-3 text-sm disabled:opacity-50">{L.makeStory}</button>
            </div>
          </div>

          <label className="block space-y-2">
            <span className="text-sm text-slate-300">{L.project}</span>
            <select
              value={projectId}
              onChange={(e) => setProjectId(e.target.value)}
              className="w-full rounded-lg bg-slate-800 border border-slate-600 p-3"
            >
              <option value="">{L.pick}</option>
              {projects.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
            </select>
          </label>

          <div className="space-y-2">
            <span className="text-sm text-slate-300">{L.provider}</span>
            <div className="grid gap-2 sm:grid-cols-2">
              <button
                onClick={() => setProvider('slideshow')}
                className={`rounded-lg border p-3 text-start ${provider === 'slideshow' ? 'border-purple-500 bg-purple-500/10' : 'border-slate-600'}`}
              >{L.free}</button>
              <button
                disabled={!paidOk}
                onClick={() => setProvider('fal')}
                className={`rounded-lg border p-3 text-start disabled:opacity-50 ${provider === 'fal' ? 'border-purple-500 bg-purple-500/10' : 'border-slate-600'}`}
              >
                {L.paid}
                {!paidOk && <span className="block text-xs text-amber-400 mt-1">{L.unavailable}{info?.providers.fal.reason ? `: ${info.providers.fal.reason}` : ''}</span>}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-sm text-slate-300">{L.style}</span>
            <div className="flex gap-2 flex-wrap">
              {(['cartoon', 'realistic', 'cinematic'] as Style[]).map((s) => (
                <button
                  key={s}
                  onClick={() => setStyle(s)}
                  className={`rounded-full border px-4 py-1.5 text-sm ${style === s ? 'border-purple-500 bg-purple-500/10' : 'border-slate-600'}`}
                >{L[s]}</button>
              ))}
            </div>
          </div>

          {info && provider === 'fal' && (
            <div className="flex items-center gap-2 text-sm text-slate-300">
              <Wallet className="w-4 h-4" />
              {L.budget}: ${info.spend.usd.toFixed(2)} / ${info.spend.budgetUsd.toFixed(2)}
            </div>
          )}

          <button
            onClick={start}
            disabled={!projectId || running}
            className="w-full rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 p-3 font-semibold flex items-center justify-center gap-2"
          >
            {running ? <><Loader2 className="w-4 h-4 animate-spin" />{L.working}</> : <><Sparkles className="w-4 h-4" />{L.start}</>}
          </button>
          <p className="text-xs text-slate-500">{L.note}</p>
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />{error}</div>
      )}

      {job && (
        <div className="rounded-xl border border-slate-700 bg-slate-900/50 p-5 space-y-4">
          <div className="flex justify-between text-sm"><span>{job.message}</span><span>{job.progress}%</span></div>
          <div className="h-2 rounded bg-slate-800 overflow-hidden"><div className="h-full bg-purple-500 transition-all" style={{ width: `${job.progress}%` }} /></div>
          {job.estimatedCostUsd ? <div className="text-xs text-slate-400">{L.cost}: ≈ ${job.estimatedCostUsd.toFixed(2)}</div> : null}
          {job.status === 'failed' && (
            <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3 text-sm flex gap-2"><AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />{job.error}</div>
          )}
          {job.status === 'completed' && job.streamUrl && (
            <div className="space-y-3">
              <p className="font-semibold text-emerald-400">{L.done}</p>
              <video src={job.streamUrl} controls playsInline className="w-full rounded-lg bg-black" />
              {job.audioWarning && (
                <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">{L.audioWarn}: {job.audioWarning}</div>
              )}
              {job.totalScenes ? <div className="text-xs text-slate-400">{L.narrated}: {job.narratedScenes ?? 0}/{job.totalScenes}</div> : null}
              <div className="flex flex-wrap gap-2">
                <button onClick={() => saveToGallery(job.downloadUrl!)} disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-60 px-4 py-2 text-sm font-semibold">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Smartphone className="w-4 h-4" />}{saving ? L.saving : L.save}
                </button>
                <a href={job.downloadUrl} className="inline-flex items-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-2 text-sm font-semibold">
                  <Download className="w-4 h-4" />{L.download}
                </a>
              </div>
              <p className="text-xs text-slate-500">{L.saveHint}</p>
            </div>
          )}
          <details className="text-xs text-slate-400">
            <summary className="cursor-pointer">{L.logs}</summary>
            <pre className="mt-2 whitespace-pre-wrap" dir="ltr">{job.logs.join('\n')}</pre>
          </details>
        </div>
      )}
    </div>
  );
};
