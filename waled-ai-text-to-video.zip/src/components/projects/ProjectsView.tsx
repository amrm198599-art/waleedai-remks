import React from 'react';
import { useLocalization } from '../../lib/localization';
import { Project } from '../../types';
import { CharacterCanvas } from '../studio/CharacterCanvas';
import {
  FolderKanban,
  Video,
  Plus,
  Edit3,
  Trash2,
  Download,
  Clock,
  Layers,
  CheckCircle2,
} from 'lucide-react';

interface ProjectsViewProps {
  projects: Project[];
  onOpenProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
  onNavigate: (view: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  onOpenProject,
  onDeleteProject,
  onNavigate,
}) => {
  const { language, t } = useLocalization();

  return (
    <div className="space-y-6 pb-16">
      <div className="glass-panel rounded-3xl p-6 border border-purple-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white flex items-center gap-2">
            <FolderKanban className="w-6 h-6 text-purple-400" />
            <span>{t('nav.my_projects')}</span>
          </h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            {language === 'ar'
              ? 'إدارة مشاريعك الكرتونية والتعديل عليها وتصدير مقاطع الفيديو'
              : 'Manage, edit, duplicate, and export your animated cartoon projects'}
          </p>
        </div>

        <button
          onClick={() => onNavigate('create')}
          className="px-5 py-2.5 rounded-2xl bg-waled-gradient hover:opacity-95 text-white font-bold text-xs shadow-md shadow-purple-600/30 flex items-center gap-2 self-start sm:self-auto transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t('nav.create_video')}</span>
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="glass-panel rounded-3xl p-12 text-center space-y-4 border border-purple-500/20 max-w-lg mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-center mx-auto text-purple-400">
            <FolderKanban className="w-7 h-7" />
          </div>
          <p className="text-base font-bold text-white">{t('dashboard.no_projects')}</p>
          <button
            onClick={() => onNavigate('create')}
            className="px-5 py-2.5 rounded-xl bg-waled-gradient text-white font-bold text-xs shadow-md"
          >
            {t('dashboard.cta_create')}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((proj) => {
            const char = proj.scenes[0]?.characters[0]?.characterId || 'bader_rabbit';
            const bg = proj.scenes[0]?.backgroundId || 'enchanted_forest';
            return (
              <div
                key={proj.id}
                className="glass-panel rounded-3xl overflow-hidden border border-purple-500/20 hover:border-purple-500/40 transition flex flex-col justify-between group"
              >
                <div className="p-4 space-y-3">
                  <div className="relative h-40 rounded-2xl overflow-hidden bg-slate-900 border border-purple-500/20 flex items-center justify-center">
                    <CharacterCanvas
                      characterId={char}
                      action="idle"
                      backgroundId={bg}
                      width={320}
                      height={160}
                      scale={0.8}
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-slate-950/80 text-cyan-300 border border-purple-500/30">
                      {proj.aspectRatio} • {proj.duration}s
                    </div>
                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded-md text-[10px] font-bold bg-purple-950/80 text-purple-200 border border-purple-500/30">
                      {proj.language === 'ar' ? 'عربي' : 'EN'}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white line-clamp-1 group-hover:text-purple-300 transition">
                      {proj.title}
                    </h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">{proj.description}</p>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-purple-500/10">
                    <span>{proj.scenes.length} {language === 'ar' ? 'مشاهد' : 'scenes'}</span>
                    <span className="flex items-center gap-1 text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {proj.status === 'completed'
                        ? language === 'ar' ? 'تم التصدير' : 'Rendered'
                        : language === 'ar' ? 'مسودة جاهزة' : 'Draft'}
                    </span>
                  </div>
                </div>

                <div className="px-4 py-3 bg-slate-950/70 border-t border-purple-500/20 flex items-center justify-between gap-2">
                  <button
                    onClick={() => onOpenProject(proj.id)}
                    className="flex-1 py-2 rounded-xl bg-purple-600/80 hover:bg-purple-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>{language === 'ar' ? 'تعديل' : 'Edit'}</span>
                  </button>

                  {proj.renderedVideoUrl && (
                    <a
                      href={proj.renderedVideoUrl}
                      download={`${proj.title.replace(/\s+/g, '_')}.mp4`}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white transition"
                      title={t('common.download')}
                    >
                      <Download className="w-4 h-4 text-cyan-400" />
                    </a>
                  )}

                  <button
                    onClick={() => onDeleteProject(proj.id)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                    title={t('common.delete')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
