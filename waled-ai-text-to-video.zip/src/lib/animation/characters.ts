import {
  CharacterId,
  CharacterAction,
  FacialExpression,
} from '../../types';

export interface CharacterDefinition {
  id: CharacterId;
  nameEn: string;
  nameAr: string;
  species: string;
  colorScheme: {
    primary: string;
    secondary: string;
    accent: string;
    belly: string;
  };
  supportedActions: CharacterAction[];
  supportedExpressions: FacialExpression[];
  descriptionEn: string;
  descriptionAr: string;
}

export const CHARACTER_CATALOG: CharacterDefinition[] = [
  {
    id: 'bader_rabbit',
    nameEn: 'Bader the Rabbit',
    nameAr: 'الأرنب بدر',
    species: 'Rabbit',
    colorScheme: {
      primary: '#f8fafc',
      secondary: '#fbcfe8',
      accent: '#f97316',
      belly: '#ffffff',
    },
    supportedActions: ['idle', 'walk', 'run', 'jump', 'wave', 'talk', 'laugh', 'celebrate', 'fall', 'look_left', 'look_right'],
    supportedExpressions: ['happy', 'talking', 'surprised', 'laughing', 'determined', 'silly'],
    descriptionEn: 'Cheerful, curious rabbit with long bouncing ears and a crisp carrot accessory',
    descriptionAr: 'أرنب ذكي ومرح بأذنين طويلتين ونشاط دائم وجزرة مميزة',
  },
  {
    id: 'faris_bear',
    nameEn: 'Faris the Bear',
    nameAr: 'الدب فارس',
    species: 'Bear',
    colorScheme: {
      primary: '#92400e',
      secondary: '#b45309',
      accent: '#fef08a',
      belly: '#fde68a',
    },
    supportedActions: ['idle', 'walk', 'run', 'jump', 'wave', 'talk', 'laugh', 'celebrate', 'fall', 'look_left', 'look_right'],
    supportedExpressions: ['happy', 'talking', 'surprised', 'laughing', 'determined', 'silly'],
    descriptionEn: 'Kindhearted, strong brown bear with a sweet tooth for honey and bananas',
    descriptionAr: 'دب بني طيب القلب وشجاع يعشق العسل والمرح مع أصدقائه',
  },
  {
    id: 'maymoun_monkey',
    nameEn: 'Maymoun the Monkey',
    nameAr: 'القرد ميمون',
    species: 'Monkey',
    colorScheme: {
      primary: '#b45309',
      secondary: '#fed7aa',
      accent: '#fde047',
      belly: '#ffedd5',
    },
    supportedActions: ['idle', 'walk', 'run', 'jump', 'wave', 'talk', 'laugh', 'celebrate', 'fall', 'look_left', 'look_right'],
    supportedExpressions: ['happy', 'talking', 'surprised', 'laughing', 'determined', 'silly'],
    descriptionEn: 'Agile, playful monkey who loves bananas, high jumps, and silly acrobatics',
    descriptionAr: 'قرد رشيق ومشاغب يعشق الموز والقفزات البهلوانية والمقالب اللطيفة',
  },
  {
    id: 'salma_explorer',
    nameEn: 'Salma the Explorer',
    nameAr: 'سلمى المستكشفة',
    species: 'Human',
    colorScheme: {
      primary: '#3b82f6',
      secondary: '#fde047',
      accent: '#ef4444',
      belly: '#ffffff',
    },
    supportedActions: ['idle', 'walk', 'run', 'jump', 'wave', 'talk', 'laugh', 'celebrate', 'fall', 'look_left', 'look_right'],
    supportedExpressions: ['happy', 'talking', 'surprised', 'laughing', 'determined', 'silly'],
    descriptionEn: 'Courageous young explorer with safari gear, backpack, and binoculars',
    descriptionAr: 'مستكشفة شجاعة ترتدي قبعة السفاري وحقيبة المغامرات وتستكشف الغابة',
  },
  {
    id: 'robo_z',
    nameEn: 'Robo-Z',
    nameAr: 'الروبوت زيرو',
    species: 'Robot',
    colorScheme: {
      primary: '#64748b',
      secondary: '#38bdf8',
      accent: '#a855f7',
      belly: '#0f172a',
    },
    supportedActions: ['idle', 'walk', 'run', 'jump', 'wave', 'talk', 'laugh', 'celebrate', 'fall', 'look_left', 'look_right'],
    supportedExpressions: ['happy', 'talking', 'surprised', 'laughing', 'determined', 'silly'],
    descriptionEn: 'Friendly retro robot with a glowing antenna, digital screen face, and rocket thrust',
    descriptionAr: 'روبوت ودود ومرح مزود بهوائي مشع وشاشة رقمية تعبر عن المشاعر ومحركات طيران',
  },
];

export function renderCharacterRig(
  ctx: CanvasRenderingContext2D,
  characterId: CharacterId,
  action: CharacterAction,
  expression: FacialExpression = 'happy',
  time: number,
  x: number, // canvas X
  y: number, // canvas Y (base of feet)
  scale: number = 1.0,
  flipX: boolean = false
) {
  ctx.save();
  ctx.translate(x, y);

  if (flipX) {
    ctx.scale(-1, 1);
  }

  ctx.scale(scale, scale);

  switch (characterId) {
    case 'bader_rabbit':
      drawRabbit(ctx, action, expression, time);
      break;
    case 'faris_bear':
      drawBear(ctx, action, expression, time);
      break;
    case 'maymoun_monkey':
      drawMonkey(ctx, action, expression, time);
      break;
    case 'salma_explorer':
      drawExplorer(ctx, action, expression, time);
      break;
    case 'robo_z':
      drawRobot(ctx, action, expression, time);
      break;
    default:
      drawRabbit(ctx, action, expression, time);
  }

  ctx.restore();
}

// -----------------------------------------------------------------------------
// 1. BADER THE RABBIT (الأرنب بدر)
// -----------------------------------------------------------------------------
function drawRabbit(
  ctx: CanvasRenderingContext2D,
  action: CharacterAction,
  expression: FacialExpression,
  time: number
) {
  const isTalking = action === 'talk';
  const isWalking = action === 'walk';
  const isRunning = action === 'run';
  const isJumping = action === 'jump';
  const isWaving = action === 'wave';
  const isLaughing = action === 'laugh';
  const isCelebrating = action === 'celebrate';
  const isFalling = action === 'fall';
  const isLookLeft = action === 'look_left';
  const isLookRight = action === 'look_right';

  // Dynamic kinematic calculations
  let bodyY = 0;
  let bodyRot = 0;
  let leftEarRot = -0.15;
  let rightEarRot = 0.15;
  let leftArmRot = 0.2;
  let rightArmRot = -0.2;
  let leftLegRot = 0;
  let rightLegRot = 0;

  if (isFalling) {
    ctx.rotate(1.4);
    bodyY = 30;
    // Dizzy stars overhead
    drawDizzyStars(ctx, 0, -110, time);
  } else if (isJumping) {
    const jumpCycle = Math.sin(time * 6);
    bodyY = -Math.abs(jumpCycle) * 45;
    leftLegRot = 0.4;
    rightLegRot = -0.4;
    leftArmRot = -1.2;
    rightArmRot = 1.2;
    leftEarRot = -0.4;
    rightEarRot = 0.4;
  } else if (isRunning) {
    bodyY = Math.abs(Math.sin(time * 14)) * 6;
    bodyRot = 0.2;
    leftLegRot = Math.sin(time * 14) * 0.7;
    rightLegRot = -Math.sin(time * 14) * 0.7;
    leftArmRot = -Math.sin(time * 14) * 0.8;
    rightArmRot = Math.sin(time * 14) * 0.8;
    leftEarRot = -0.4 + Math.sin(time * 14) * 0.1;
    rightEarRot = -0.3 + Math.cos(time * 14) * 0.1;
    drawDustPuff(ctx, -25, -5, time);
  } else if (isWalking) {
    bodyY = Math.abs(Math.sin(time * 8)) * 4;
    leftLegRot = Math.sin(time * 8) * 0.45;
    rightLegRot = -Math.sin(time * 8) * 0.45;
    leftArmRot = -Math.sin(time * 8) * 0.5;
    rightArmRot = Math.sin(time * 8) * 0.5;
    leftEarRot = -0.15 + Math.sin(time * 8) * 0.08;
    rightEarRot = 0.15 - Math.sin(time * 8) * 0.08;
  } else if (isWaving) {
    bodyY = Math.sin(time * 3) * 2;
    leftArmRot = -2.2 + Math.sin(time * 10) * 0.4;
  } else if (isCelebrating) {
    bodyY = -Math.abs(Math.sin(time * 8)) * 15;
    leftArmRot = -2.4 + Math.sin(time * 8) * 0.2;
    rightArmRot = 2.4 - Math.sin(time * 8) * 0.2;
    drawCelebrationStars(ctx, 0, -90, time);
  } else if (isLaughing) {
    bodyY = Math.sin(time * 18) * 3;
    leftEarRot = -0.2 + Math.sin(time * 18) * 0.1;
    rightEarRot = 0.2 + Math.sin(time * 18) * 0.1;
    drawLaughNotes(ctx, 20, -80, time);
  } else {
    // Idle breathing
    bodyY = Math.sin(time * 3) * 2;
    leftEarRot = -0.15 + Math.sin(time * 2) * 0.05;
    rightEarRot = 0.15 + Math.cos(time * 2) * 0.05;
  }

  ctx.translate(0, bodyY);
  ctx.rotate(bodyRot);

  // Feet / Legs (drawn behind body)
  // Left leg
  ctx.save();
  ctx.translate(-14, -18);
  ctx.rotate(leftLegRot);
  ctx.fillStyle = '#e2e8f0';
  ctx.beginPath();
  ctx.ellipse(0, 10, 8, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  // Foot pad
  ctx.fillStyle = '#fbcfe8';
  ctx.beginPath();
  ctx.ellipse(0, 16, 5, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Right leg
  ctx.save();
  ctx.translate(14, -18);
  ctx.rotate(rightLegRot);
  ctx.fillStyle = '#e2e8f0';
  ctx.beginPath();
  ctx.ellipse(0, 10, 8, 14, 0, 0, Math.PI * 2);
  ctx.fill();
  // Foot pad
  ctx.fillStyle = '#fbcfe8';
  ctx.beginPath();
  ctx.ellipse(0, 16, 5, 4, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Fluffy tail
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(-22, -26, 8, 0, Math.PI * 2);
  ctx.fill();

  // Torso / Body
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, -38, 22, 26, 0, 0, Math.PI * 2);
  ctx.fill();

  // White belly
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(0, -36, 14, 18, 0, 0, Math.PI * 2);
  ctx.fill();

  // Left Arm
  ctx.save();
  ctx.translate(-18, -45);
  ctx.rotate(leftArmRot);
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, 10, 6, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Right Arm (holding crisp carrot)
  ctx.save();
  ctx.translate(18, -45);
  ctx.rotate(rightArmRot);
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, 10, 6, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  // Carrot
  drawCarrot(ctx, 4, 16);
  ctx.restore();

  // Head
  ctx.save();
  ctx.translate(0, -70);

  // Ears
  // Left Ear
  ctx.save();
  ctx.translate(-12, -18);
  ctx.rotate(leftEarRot);
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, -22, 9, 26, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fbcfe8';
  ctx.beginPath();
  ctx.ellipse(0, -22, 5, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Right Ear
  ctx.save();
  ctx.translate(12, -18);
  ctx.rotate(rightEarRot);
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, -22, 9, 26, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fbcfe8';
  ctx.beginPath();
  ctx.ellipse(0, -22, 5, 18, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Head circle
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, 0, 24, 20, 0, 0, Math.PI * 2);
  ctx.fill();

  // Rosy cheeks
  ctx.fillStyle = 'rgba(251, 146, 60, 0.4)';
  ctx.beginPath();
  ctx.arc(-14, 4, 5, 0, Math.PI * 2);
  ctx.arc(14, 4, 5, 0, Math.PI * 2);
  ctx.fill();

  // Eyes
  drawEyes(ctx, expression, isLookLeft, isLookRight, time);

  // Pink cute nose
  ctx.fillStyle = '#f472b6';
  ctx.beginPath();
  ctx.moveTo(0, 2);
  ctx.lineTo(-4, -1);
  ctx.lineTo(4, -1);
  ctx.closePath();
  ctx.fill();

  // Whiskers
  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-10, 3);
  ctx.lineTo(-24, 0);
  ctx.moveTo(-10, 6);
  ctx.lineTo(-24, 7);
  ctx.moveTo(10, 3);
  ctx.lineTo(24, 0);
  ctx.moveTo(10, 6);
  ctx.lineTo(24, 7);
  ctx.stroke();

  // Mouth / Lip-Sync
  drawMouth(ctx, isTalking, expression, time);

  ctx.restore(); // head
}

// -----------------------------------------------------------------------------
// 2. FARIS THE BEAR (الدب فارس)
// -----------------------------------------------------------------------------
function drawBear(
  ctx: CanvasRenderingContext2D,
  action: CharacterAction,
  expression: FacialExpression,
  time: number
) {
  const isTalking = action === 'talk';
  const isWalking = action === 'walk';
  const isRunning = action === 'run';
  const isJumping = action === 'jump';
  const isWaving = action === 'wave';
  const isLaughing = action === 'laugh';
  const isCelebrating = action === 'celebrate';
  const isFalling = action === 'fall';
  const isLookLeft = action === 'look_left';
  const isLookRight = action === 'look_right';

  let bodyY = 0;
  let bodyRot = 0;
  let leftArmRot = 0.2;
  let rightArmRot = -0.2;
  let leftLegRot = 0;
  let rightLegRot = 0;

  if (isFalling) {
    ctx.rotate(1.4);
    bodyY = 30;
    drawDizzyStars(ctx, 0, -120, time);
  } else if (isJumping) {
    const jumpCycle = Math.sin(time * 6);
    bodyY = -Math.abs(jumpCycle) * 35;
    leftLegRot = 0.3;
    rightLegRot = -0.3;
    leftArmRot = -1.2;
    rightArmRot = 1.2;
  } else if (isRunning) {
    bodyY = Math.abs(Math.sin(time * 12)) * 6;
    bodyRot = 0.15;
    leftLegRot = Math.sin(time * 12) * 0.6;
    rightLegRot = -Math.sin(time * 12) * 0.6;
    leftArmRot = -Math.sin(time * 12) * 0.7;
    rightArmRot = Math.sin(time * 12) * 0.7;
    drawDustPuff(ctx, -30, -5, time);
  } else if (isWalking) {
    bodyY = Math.abs(Math.sin(time * 7)) * 4;
    leftLegRot = Math.sin(time * 7) * 0.4;
    rightLegRot = -Math.sin(time * 7) * 0.4;
    leftArmRot = -Math.sin(time * 7) * 0.45;
    rightArmRot = Math.sin(time * 7) * 0.45;
  } else if (isWaving) {
    leftArmRot = -2.2 + Math.sin(time * 10) * 0.35;
  } else if (isCelebrating) {
    bodyY = -Math.abs(Math.sin(time * 8)) * 12;
    leftArmRot = -2.3;
    rightArmRot = 2.3;
    drawCelebrationStars(ctx, 0, -110, time);
  } else if (isLaughing) {
    bodyY = Math.sin(time * 16) * 4;
    drawLaughNotes(ctx, 24, -90, time);
  } else {
    bodyY = Math.sin(time * 2.5) * 2;
  }

  ctx.translate(0, bodyY);
  ctx.rotate(bodyRot);

  // Big sturdy bear legs
  ctx.save();
  ctx.translate(-18, -20);
  ctx.rotate(leftLegRot);
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.roundRect(-8, 0, 16, 24, 8);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(18, -20);
  ctx.rotate(rightLegRot);
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.roundRect(-8, 0, 16, 24, 8);
  ctx.fill();
  ctx.restore();

  // Torso / Big Huggable Body
  ctx.fillStyle = '#92400e';
  ctx.beginPath();
  ctx.ellipse(0, -45, 30, 34, 0, 0, Math.PI * 2);
  ctx.fill();

  // Honey belly
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.ellipse(0, -42, 20, 24, 0, 0, Math.PI * 2);
  ctx.fill();

  // Left Arm
  ctx.save();
  ctx.translate(-26, -55);
  ctx.rotate(leftArmRot);
  ctx.fillStyle = '#92400e';
  ctx.beginPath();
  ctx.ellipse(0, 14, 9, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Right Arm (holding honey jar or banana)
  ctx.save();
  ctx.translate(26, -55);
  ctx.rotate(rightArmRot);
  ctx.fillStyle = '#92400e';
  ctx.beginPath();
  ctx.ellipse(0, 14, 9, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  // Honey Pot
  drawHoneyPot(ctx, 6, 22);
  ctx.restore();

  // Head
  ctx.save();
  ctx.translate(0, -85);

  // Rounded ears
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.arc(-22, -18, 11, 0, Math.PI * 2);
  ctx.arc(22, -18, 11, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(-22, -18, 6, 0, Math.PI * 2);
  ctx.arc(22, -18, 6, 0, Math.PI * 2);
  ctx.fill();

  // Head main
  ctx.fillStyle = '#92400e';
  ctx.beginPath();
  ctx.ellipse(0, 0, 28, 24, 0, 0, Math.PI * 2);
  ctx.fill();

  // Muzzle
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.ellipse(0, 6, 16, 12, 0, 0, Math.PI * 2);
  ctx.fill();

  // Big black nose
  ctx.fillStyle = '#1e293b';
  ctx.beginPath();
  ctx.ellipse(0, 2, 7, 5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Eyes
  drawEyes(ctx, expression, isLookLeft, isLookRight, time);

  // Mouth
  drawMouth(ctx, isTalking, expression, time);

  ctx.restore();
}

// -----------------------------------------------------------------------------
// 3. MAYMOUN THE MONKEY (القرد ميمون)
// -----------------------------------------------------------------------------
function drawMonkey(
  ctx: CanvasRenderingContext2D,
  action: CharacterAction,
  expression: FacialExpression,
  time: number
) {
  const isTalking = action === 'talk';
  const isWalking = action === 'walk';
  const isRunning = action === 'run';
  const isJumping = action === 'jump';
  const isWaving = action === 'wave';
  const isLaughing = action === 'laugh';
  const isCelebrating = action === 'celebrate';
  const isFalling = action === 'fall';
  const isLookLeft = action === 'look_left';
  const isLookRight = action === 'look_right';

  let bodyY = 0;
  let bodyRot = 0;
  let leftArmRot = 0.4;
  let rightArmRot = -0.4;
  let leftLegRot = 0;
  let rightLegRot = 0;
  let tailWag = Math.sin(time * 4) * 0.3;

  if (isFalling) {
    ctx.rotate(1.4);
    bodyY = 25;
    drawDizzyStars(ctx, 0, -100, time);
  } else if (isJumping) {
    const jumpCycle = Math.sin(time * 7);
    bodyY = -Math.abs(jumpCycle) * 50;
    leftLegRot = 0.6;
    rightLegRot = -0.6;
    leftArmRot = -1.6;
    rightArmRot = 1.6;
    tailWag = Math.sin(time * 12) * 0.8;
  } else if (isRunning) {
    bodyY = Math.abs(Math.sin(time * 14)) * 6;
    bodyRot = 0.25;
    leftLegRot = Math.sin(time * 14) * 0.8;
    rightLegRot = -Math.sin(time * 14) * 0.8;
    leftArmRot = -Math.sin(time * 14) * 0.9;
    rightArmRot = Math.sin(time * 14) * 0.9;
    tailWag = 0.6 + Math.sin(time * 14) * 0.4;
    drawDustPuff(ctx, -25, -5, time);
  } else if (isWalking) {
    bodyY = Math.abs(Math.sin(time * 8)) * 4;
    leftLegRot = Math.sin(time * 8) * 0.5;
    rightLegRot = -Math.sin(time * 8) * 0.5;
    leftArmRot = -Math.sin(time * 8) * 0.55;
    rightArmRot = Math.sin(time * 8) * 0.55;
  } else if (isWaving) {
    leftArmRot = -2.2 + Math.sin(time * 10) * 0.4;
  } else if (isCelebrating) {
    bodyY = -Math.abs(Math.sin(time * 9)) * 18;
    leftArmRot = -2.5;
    rightArmRot = 2.5;
    drawCelebrationStars(ctx, 0, -100, time);
  } else if (isLaughing) {
    bodyY = Math.sin(time * 18) * 4;
    drawLaughNotes(ctx, 22, -80, time);
  } else {
    bodyY = Math.sin(time * 3) * 2;
  }

  ctx.translate(0, bodyY);
  ctx.rotate(bodyRot);

  // Curly tail
  ctx.save();
  ctx.translate(-16, -30);
  ctx.rotate(tailWag);
  ctx.strokeStyle = '#b45309';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.bezierCurveTo(-20, -10, -35, -40, -15, -50);
  ctx.stroke();
  ctx.restore();

  // Legs
  ctx.save();
  ctx.translate(-12, -16);
  ctx.rotate(leftLegRot);
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, 8, 6, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(12, -16);
  ctx.rotate(rightLegRot);
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, 8, 6, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Torso
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, -34, 20, 24, 0, 0, Math.PI * 2);
  ctx.fill();

  // Tummy
  ctx.fillStyle = '#ffedd5';
  ctx.beginPath();
  ctx.ellipse(0, -32, 13, 16, 0, 0, Math.PI * 2);
  ctx.fill();

  // Left arm
  ctx.save();
  ctx.translate(-16, -42);
  ctx.rotate(leftArmRot);
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, 10, 5, 13, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Right arm (holding golden banana!)
  ctx.save();
  ctx.translate(16, -42);
  ctx.rotate(rightArmRot);
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, 10, 5, 13, 0, 0, Math.PI * 2);
  ctx.fill();
  drawBanana(ctx, 6, 16);
  ctx.restore();

  // Head
  ctx.save();
  ctx.translate(0, -68);

  // Big side ears
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.arc(-22, 0, 12, 0, Math.PI * 2);
  ctx.arc(22, 0, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffedd5';
  ctx.beginPath();
  ctx.arc(-22, 0, 7, 0, Math.PI * 2);
  ctx.arc(22, 0, 7, 0, Math.PI * 2);
  ctx.fill();

  // Head main
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.arc(0, 0, 22, 0, Math.PI * 2);
  ctx.fill();

  // Face mask (heart shaped monkey face)
  ctx.fillStyle = '#ffedd5';
  ctx.beginPath();
  ctx.arc(-8, -4, 11, 0, Math.PI * 2);
  ctx.arc(8, -4, 11, 0, Math.PI * 2);
  ctx.ellipse(0, 6, 14, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // Nostrils
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.arc(-3, 3, 2, 0, Math.PI * 2);
  ctx.arc(3, 3, 2, 0, Math.PI * 2);
  ctx.fill();

  // Eyes
  drawEyes(ctx, expression, isLookLeft, isLookRight, time);

  // Mouth
  drawMouth(ctx, isTalking, expression, time);

  ctx.restore();
}

// -----------------------------------------------------------------------------
// 4. SALMA THE EXPLORER (سلمى المستكشفة)
// -----------------------------------------------------------------------------
function drawExplorer(
  ctx: CanvasRenderingContext2D,
  action: CharacterAction,
  expression: FacialExpression,
  time: number
) {
  const isTalking = action === 'talk';
  const isWalking = action === 'walk';
  const isRunning = action === 'run';
  const isJumping = action === 'jump';
  const isWaving = action === 'wave';
  const isLaughing = action === 'laugh';
  const isCelebrating = action === 'celebrate';
  const isFalling = action === 'fall';
  const isLookLeft = action === 'look_left';
  const isLookRight = action === 'look_right';

  let bodyY = 0;
  let bodyRot = 0;
  let leftArmRot = 0.2;
  let rightArmRot = -0.2;
  let leftLegRot = 0;
  let rightLegRot = 0;

  if (isFalling) {
    ctx.rotate(1.4);
    bodyY = 30;
    drawDizzyStars(ctx, 0, -110, time);
  } else if (isJumping) {
    const jumpCycle = Math.sin(time * 6);
    bodyY = -Math.abs(jumpCycle) * 40;
    leftLegRot = 0.4;
    rightLegRot = -0.4;
    leftArmRot = -1.4;
    rightArmRot = 1.4;
  } else if (isRunning) {
    bodyY = Math.abs(Math.sin(time * 13)) * 5;
    bodyRot = 0.18;
    leftLegRot = Math.sin(time * 13) * 0.7;
    rightLegRot = -Math.sin(time * 13) * 0.7;
    leftArmRot = -Math.sin(time * 13) * 0.75;
    rightArmRot = Math.sin(time * 13) * 0.75;
    drawDustPuff(ctx, -26, -5, time);
  } else if (isWalking) {
    bodyY = Math.abs(Math.sin(time * 8)) * 4;
    leftLegRot = Math.sin(time * 8) * 0.45;
    rightLegRot = -Math.sin(time * 8) * 0.45;
    leftArmRot = -Math.sin(time * 8) * 0.5;
    rightArmRot = Math.sin(time * 8) * 0.5;
  } else if (isWaving) {
    leftArmRot = -2.2 + Math.sin(time * 10) * 0.35;
  } else if (isCelebrating) {
    bodyY = -Math.abs(Math.sin(time * 8)) * 14;
    leftArmRot = -2.4;
    rightArmRot = 2.4;
    drawCelebrationStars(ctx, 0, -110, time);
  } else if (isLaughing) {
    bodyY = Math.sin(time * 16) * 3;
    drawLaughNotes(ctx, 22, -85, time);
  } else {
    bodyY = Math.sin(time * 3) * 2;
  }

  ctx.translate(0, bodyY);
  ctx.rotate(bodyRot);

  // Explorer Boots
  ctx.save();
  ctx.translate(-12, -18);
  ctx.rotate(leftLegRot);
  ctx.fillStyle = '#b45309';
  ctx.fillRect(-6, 0, 12, 18);
  ctx.fillStyle = '#78350f';
  ctx.fillRect(-8, 12, 16, 8);
  ctx.restore();

  ctx.save();
  ctx.translate(12, -18);
  ctx.rotate(rightLegRot);
  ctx.fillStyle = '#b45309';
  ctx.fillRect(-6, 0, 12, 18);
  ctx.fillStyle = '#78350f';
  ctx.fillRect(-8, 12, 16, 8);
  ctx.restore();

  // Safari Shorts
  ctx.fillStyle = '#d97706';
  ctx.fillRect(-16, -26, 32, 12);

  // Safari Vest & Shirt
  ctx.fillStyle = '#3b82f6';
  ctx.beginPath();
  ctx.roundRect(-16, -52, 32, 28, 6);
  ctx.fill();

  // Vest Pockets
  ctx.fillStyle = '#1d4ed8';
  ctx.fillRect(-12, -44, 8, 8);
  ctx.fillRect(4, -44, 8, 8);

  // Binoculars strap around neck
  ctx.strokeStyle = '#1e293b';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-10, -52);
  ctx.lineTo(0, -36);
  ctx.lineTo(10, -52);
  ctx.stroke();

  // Binoculars
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(-7, -36, 14, 8);
  ctx.fillStyle = '#38bdf8';
  ctx.beginPath();
  ctx.arc(-3, -32, 3, 0, Math.PI * 2);
  ctx.arc(3, -32, 3, 0, Math.PI * 2);
  ctx.fill();

  // Left Arm
  ctx.save();
  ctx.translate(-18, -48);
  ctx.rotate(leftArmRot);
  ctx.fillStyle = '#fdba74';
  ctx.beginPath();
  ctx.ellipse(0, 10, 5, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Right Arm
  ctx.save();
  ctx.translate(18, -48);
  ctx.rotate(rightArmRot);
  ctx.fillStyle = '#fdba74';
  ctx.beginPath();
  ctx.ellipse(0, 10, 5, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Head
  ctx.save();
  ctx.translate(0, -74);

  // Face
  ctx.fillStyle = '#fed7aa';
  ctx.beginPath();
  ctx.ellipse(0, 0, 20, 18, 0, 0, Math.PI * 2);
  ctx.fill();

  // Hair
  ctx.fillStyle = '#451a03';
  ctx.beginPath();
  ctx.arc(0, -4, 21, Math.PI, Math.PI * 2);
  ctx.fill();

  // Safari Explorer Hat
  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  // Hat brim
  ctx.ellipse(0, -12, 30, 8, 0, 0, Math.PI * 2);
  ctx.fill();
  // Hat crown
  ctx.beginPath();
  ctx.roundRect(-16, -26, 32, 16, [10, 10, 0, 0]);
  ctx.fill();
  // Hat band
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(-16, -14, 32, 4);

  // Eyes
  drawEyes(ctx, expression, isLookLeft, isLookRight, time);

  // Rosy cheeks
  ctx.fillStyle = 'rgba(244, 63, 94, 0.4)';
  ctx.beginPath();
  ctx.arc(-11, 4, 4, 0, Math.PI * 2);
  ctx.arc(11, 4, 4, 0, Math.PI * 2);
  ctx.fill();

  // Mouth
  drawMouth(ctx, isTalking, expression, time);

  ctx.restore();
}

// -----------------------------------------------------------------------------
// 5. ROBO-Z (الروبوت زيرو)
// -----------------------------------------------------------------------------
function drawRobot(
  ctx: CanvasRenderingContext2D,
  action: CharacterAction,
  expression: FacialExpression,
  time: number
) {
  const isTalking = action === 'talk';
  const isWalking = action === 'walk';
  const isRunning = action === 'run';
  const isJumping = action === 'jump';
  const isWaving = action === 'wave';
  const isLaughing = action === 'laugh';
  const isCelebrating = action === 'celebrate';
  const isFalling = action === 'fall';
  const isLookLeft = action === 'look_left';
  const isLookRight = action === 'look_right';

  let bodyY = 0;
  let bodyRot = 0;
  let leftArmRot = 0.2;
  let rightArmRot = -0.2;

  // Hovering rocket effect
  const hover = Math.sin(time * 5) * 4;

  if (isFalling) {
    ctx.rotate(1.4);
    bodyY = 25;
    drawDizzyStars(ctx, 0, -100, time);
  } else if (isJumping) {
    bodyY = -Math.abs(Math.sin(time * 6)) * 45;
    leftArmRot = -1.5;
    rightArmRot = 1.5;
  } else if (isRunning) {
    bodyY = hover;
    bodyRot = 0.2;
    leftArmRot = -Math.sin(time * 12) * 0.8;
    rightArmRot = Math.sin(time * 12) * 0.8;
  } else if (isWalking) {
    bodyY = hover;
    leftArmRot = -Math.sin(time * 8) * 0.5;
    rightArmRot = Math.sin(time * 8) * 0.5;
  } else if (isWaving) {
    leftArmRot = -2.3 + Math.sin(time * 10) * 0.4;
  } else if (isCelebrating) {
    bodyY = -Math.abs(Math.sin(time * 8)) * 16;
    leftArmRot = -2.5;
    rightArmRot = 2.5;
    drawCelebrationStars(ctx, 0, -110, time);
  } else if (isLaughing) {
    bodyY = Math.sin(time * 20) * 3;
    drawLaughNotes(ctx, 22, -90, time);
  } else {
    bodyY = hover;
  }

  ctx.translate(0, bodyY);
  ctx.rotate(bodyRot);

  // Rocket Thrusters (instead of feet)
  ctx.fillStyle = '#475569';
  ctx.beginPath();
  ctx.moveTo(-14, -14);
  ctx.lineTo(-6, -14);
  ctx.lineTo(-4, 0);
  ctx.lineTo(-16, 0);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(6, -14);
  ctx.lineTo(14, -14);
  ctx.lineTo(16, 0);
  ctx.lineTo(4, 0);
  ctx.closePath();
  ctx.fill();

  // Blue / cyan thrust flames
  const flamePulse = Math.abs(Math.sin(time * 15)) * 10;
  ctx.fillStyle = '#38bdf8';
  ctx.beginPath();
  ctx.moveTo(-15, 0);
  ctx.lineTo(-5, 0);
  ctx.lineTo(-10, 12 + flamePulse);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(5, 0);
  ctx.lineTo(15, 0);
  ctx.lineTo(10, 12 + flamePulse);
  ctx.closePath();
  ctx.fill();

  // Torso (sleek high-tech chassis)
  ctx.fillStyle = '#64748b';
  ctx.beginPath();
  ctx.roundRect(-22, -50, 44, 38, 8);
  ctx.fill();

  // Chest panel screen
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.roundRect(-15, -44, 30, 24, 4);
  ctx.fill();

  // Energy heart gauge
  const pulse = Math.abs(Math.sin(time * 3));
  ctx.fillStyle = `rgba(168, 85, 247, ${0.6 + pulse * 0.4})`;
  ctx.beginPath();
  ctx.arc(0, -32, 6, 0, Math.PI * 2);
  ctx.fill();

  // Segmented Robotic Arms
  ctx.save();
  ctx.translate(-24, -44);
  ctx.rotate(leftArmRot);
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(-4, 0, 8, 22);
  // Pincer hand
  ctx.fillStyle = '#38bdf8';
  ctx.beginPath();
  ctx.arc(0, 24, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(24, -44);
  ctx.rotate(rightArmRot);
  ctx.fillStyle = '#94a3b8';
  ctx.fillRect(-4, 0, 8, 22);
  // Pincer hand
  ctx.fillStyle = '#38bdf8';
  ctx.beginPath();
  ctx.arc(0, 24, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Neck
  ctx.fillStyle = '#334155';
  ctx.fillRect(-6, -56, 12, 6);

  // Head (monitor screen)
  ctx.save();
  ctx.translate(0, -78);

  // Antenna
  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, -18);
  ctx.lineTo(0, -32);
  ctx.stroke();

  // Glowing antenna beacon
  ctx.fillStyle = '#a855f7';
  ctx.shadowColor = '#c084fc';
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.arc(0, -34, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Head casing
  ctx.fillStyle = '#64748b';
  ctx.beginPath();
  ctx.roundRect(-24, -18, 48, 36, 10);
  ctx.fill();

  // Face screen
  ctx.fillStyle = '#0f172a';
  ctx.beginPath();
  ctx.roundRect(-19, -13, 38, 26, 6);
  ctx.fill();

  // Digital LED Eyes (cyan glowing)
  const eyeColor = '#38bdf8';
  ctx.fillStyle = eyeColor;
  ctx.shadowColor = eyeColor;
  ctx.shadowBlur = 6;

  let eyeOffsetX = 0;
  if (isLookLeft) eyeOffsetX = -3;
  if (isLookRight) eyeOffsetX = 3;

  if (expression === 'laughing' || action === 'laugh') {
    // Caret eyes: ^ ^
    ctx.strokeStyle = eyeColor;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(-12 + eyeOffsetX, -2);
    ctx.lineTo(-8 + eyeOffsetX, -6);
    ctx.lineTo(-4 + eyeOffsetX, -2);
    ctx.moveTo(4 + eyeOffsetX, -2);
    ctx.lineTo(8 + eyeOffsetX, -6);
    ctx.lineTo(12 + eyeOffsetX, -2);
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.arc(-8 + eyeOffsetX, -3, 3.5, 0, Math.PI * 2);
    ctx.arc(8 + eyeOffsetX, -3, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // Digital LED Mouth
  if (isTalking) {
    const mouthH = Math.abs(Math.sin(time * 12)) * 6 + 2;
    ctx.fillRect(-6, 4, 12, mouthH);
  } else {
    // Gentle digital smile
    ctx.strokeStyle = eyeColor;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 4, 6, 0.2, Math.PI - 0.2);
    ctx.stroke();
  }

  ctx.shadowBlur = 0;
  ctx.restore();
}

// -----------------------------------------------------------------------------
// HELPER DRAWING FUNCTIONS
// -----------------------------------------------------------------------------
function drawEyes(
  ctx: CanvasRenderingContext2D,
  expression: FacialExpression,
  isLookLeft: boolean,
  isLookRight: boolean,
  time: number
) {
  let pupilOffset = 0;
  if (isLookLeft) pupilOffset = -3;
  if (isLookRight) pupilOffset = 3;

  // Blinking cycle
  const isBlinking = Math.sin(time * 1.5) > 0.96;

  if (isBlinking || expression === 'laughing') {
    // Curved closed happy eyes
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(-8, -2, 4, Math.PI, Math.PI * 2);
    ctx.arc(8, -2, 4, Math.PI, Math.PI * 2);
    ctx.stroke();
    return;
  }

  // Eye whites
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.ellipse(-8, -2, 5, 6, 0, 0, Math.PI * 2);
  ctx.ellipse(8, -2, 5, 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Pupils
  ctx.fillStyle = '#1e293b';
  ctx.beginPath();
  ctx.arc(-8 + pupilOffset, -2, 3, 0, Math.PI * 2);
  ctx.arc(8 + pupilOffset, -2, 3, 0, Math.PI * 2);
  ctx.fill();

  // Eye specular shine
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(-9 + pupilOffset, -3.5, 1.2, 0, Math.PI * 2);
  ctx.arc(7 + pupilOffset, -3.5, 1.2, 0, Math.PI * 2);
  ctx.fill();
}

function drawMouth(
  ctx: CanvasRenderingContext2D,
  isTalking: boolean,
  expression: FacialExpression,
  time: number
) {
  if (isTalking) {
    const mouthCycle = Math.abs(Math.sin(time * 12));
    const mouthW = 8 + mouthCycle * 4;
    const mouthH = 3 + mouthCycle * 7;

    ctx.fillStyle = '#831843';
    ctx.beginPath();
    ctx.ellipse(0, 10, mouthW, mouthH, 0, 0, Math.PI * 2);
    ctx.fill();

    // Little pink tongue
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.ellipse(0, 10 + mouthH * 0.4, mouthW * 0.6, mouthH * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
  } else if (expression === 'laughing') {
    ctx.fillStyle = '#831843';
    ctx.beginPath();
    ctx.arc(0, 8, 8, 0, Math.PI);
    ctx.fill();
    ctx.fillStyle = '#f472b6';
    ctx.beginPath();
    ctx.arc(0, 12, 5, 0, Math.PI);
    ctx.fill();
  } else {
    // Normal friendly smile
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 6, 6, 0.3, Math.PI - 0.3);
    ctx.stroke();
  }
}

function drawCarrot(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(0.3);
  // Orange cone
  ctx.fillStyle = '#f97316';
  ctx.beginPath();
  ctx.moveTo(-5, 0);
  ctx.lineTo(5, 0);
  ctx.lineTo(0, 16);
  ctx.closePath();
  ctx.fill();
  // Green leaves
  ctx.fillStyle = '#22c55e';
  ctx.beginPath();
  ctx.ellipse(-2, -3, 2, 5, -0.4, 0, Math.PI * 2);
  ctx.ellipse(2, -3, 2, 5, 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawHoneyPot(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = '#b45309';
  ctx.beginPath();
  ctx.ellipse(0, 0, 8, 9, 0, 0, Math.PI * 2);
  ctx.fill();
  // Golden honey drip
  ctx.fillStyle = '#fde047';
  ctx.beginPath();
  ctx.arc(0, -6, 5, 0, Math.PI);
  ctx.fill();
  ctx.restore();
}

function drawBanana(ctx: CanvasRenderingContext2D, x: number, y: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-0.5);
  ctx.strokeStyle = '#facc15';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(0, 0, 10, 0.2, Math.PI - 0.2);
  ctx.stroke();
  // Brown tips
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.arc(9, 3, 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawDustPuff(ctx: CanvasRenderingContext2D, x: number, y: number, time: number) {
  ctx.save();
  ctx.fillStyle = 'rgba(203, 213, 225, 0.5)';
  const puff = (time * 8) % 1;
  ctx.beginPath();
  ctx.arc(x - puff * 10, y - puff * 5, 4 + puff * 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawDizzyStars(ctx: CanvasRenderingContext2D, cx: number, cy: number, time: number) {
  ctx.save();
  ctx.fillStyle = '#facc15';
  for (let i = 0; i < 3; i++) {
    const angle = time * 5 + i * (Math.PI * 2 / 3);
    const sx = cx + Math.cos(angle) * 22;
    const sy = cy + Math.sin(angle) * 8;
    ctx.beginPath();
    ctx.arc(sx, sy, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawCelebrationStars(ctx: CanvasRenderingContext2D, cx: number, cy: number, time: number) {
  ctx.save();
  ctx.fillStyle = '#fde047';
  for (let i = 0; i < 5; i++) {
    const r = 25 + Math.sin(time * 6 + i) * 10;
    const angle = i * ((Math.PI * 2) / 5) + time;
    const sx = cx + Math.cos(angle) * r;
    const sy = cy + Math.sin(angle) * r;
    ctx.beginPath();
    ctx.arc(sx, sy, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawLaughNotes(ctx: CanvasRenderingContext2D, cx: number, cy: number, time: number) {
  ctx.save();
  ctx.fillStyle = '#f472b6';
  const floatY = (time * 15) % 20;
  ctx.font = '14px sans-serif';
  ctx.fillText('♪', cx, cy - floatY);
  ctx.restore();
}
