import { Scene, VideoAspectRatio, VideoLanguage } from '../../types';
import { renderBackground } from '../animation/backgrounds';
import { renderCharacterRig } from '../animation/characters';
import { audioEngine } from '../audio/engine';

export interface RenderProgressUpdate {
  stage: 'validating_assets' | 'synthesizing_audio' | 'rendering_frames' | 'assembling_stream' | 'finalizing';
  progress: number; // 0 - 100
  messageEn: string;
  messageAr: string;
}

export interface RenderResult {
  blob: Blob;
  videoUrl: string;
  downloadUrl: string;
  streamUrl: string;
  durationSeconds: number;
  width: number;
  height: number;
  format: 'mp4' | 'webm';
}

export class VideoRenderingPipeline {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private isCancelled = false;

  constructor() {
    this.canvas = document.createElement('canvas');
    const ctx = this.canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Could not create 2D canvas context for rendering pipeline');
    this.ctx = ctx;
  }

  public static revokeUrl(url?: string | null) {
    if (url && typeof url === 'string' && url.startsWith('blob:')) {
      try {
        URL.revokeObjectURL(url);
      } catch (e) {
        // Ignored
      }
    }
  }

  public cancel() {
    this.isCancelled = true;
    audioEngine.stopAll();
  }

  public async renderVideo(
    scenes: Scene[],
    aspectRatio: VideoAspectRatio,
    lang: VideoLanguage,
    onProgress?: (update: RenderProgressUpdate) => void,
    projectId?: string
  ): Promise<RenderResult> {
    this.isCancelled = false;
    audioEngine.init();

    // 1. Setup Canvas Dimensions based on Aspect Ratio
    let width = 1280;
    let height = 720;
    if (aspectRatio === '9:16') {
      width = 720;
      height = 1280;
    } else if (aspectRatio === '1:1') {
      width = 720;
      height = 720;
    }

    this.canvas.width = width;
    this.canvas.height = height;

    // Calculate total duration
    const totalDuration = scenes.reduce((acc, s) => acc + (s.duration || 5), 0);

    onProgress?.({
      stage: 'validating_assets',
      progress: 5,
      messageEn: 'Validating vector character rigs and background textures...',
      messageAr: 'فحص نماذج الشخصيات المتجهة ونقاء الخلفيات...',
    });

    await new Promise((r) => setTimeout(r, 200));

    onProgress?.({
      stage: 'synthesizing_audio',
      progress: 15,
      messageEn: 'Synthesizing background orchestration & sound effects...',
      messageAr: 'تجهيز وتوليد المسارات الصوتية والمؤثرات...',
    });

    // 2. Setup MediaRecorder with Audio + Canvas
    const fps = 30;
    const canvasStream = this.canvas.captureStream(fps);
    const audioStream = audioEngine.getAudioStream();

    const combinedStream = new MediaStream();
    canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));
    if (audioStream) {
      audioStream.getAudioTracks().forEach((track) => combinedStream.addTrack(track));
    }

    // Determine supported mime type
    let mimeType = 'video/webm;codecs=vp9,opus';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm;codecs=vp8,opus';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm';
      }
    }

    const mediaRecorder = new MediaRecorder(combinedStream, {
      mimeType,
      videoBitsPerSecond: 2500000, // 2.5 Mbps crisp quality
    });

    const recordedChunks: Blob[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    const recordingPromise = new Promise<Blob>((resolve, reject) => {
      mediaRecorder.onstop = () => {
        const finalBlob = new Blob(recordedChunks, { type: mimeType });
        resolve(finalBlob);
      };
      mediaRecorder.onerror = (e) => reject(e);
    });

    mediaRecorder.start(100);

    // 3. Render Scenes Frame by Frame
    const dt = 1 / fps;
    let globalTime = 0;

    onProgress?.({
      stage: 'rendering_frames',
      progress: 25,
      messageEn: 'Rendering animation frames, keyframe poses and subtitles...',
      messageAr: 'رسم لقطات المشاهد وحركات الشخصيات المتجهة والترجمة...',
    });

    for (let sceneIdx = 0; sceneIdx < scenes.length; sceneIdx++) {
      if (this.isCancelled) {
        mediaRecorder.stop();
        throw new Error('Rendering cancelled by user');
      }

      const scene = scenes[sceneIdx];
      const sceneDuration = scene.duration || 5;
      const sceneFrames = Math.floor(sceneDuration * fps);

      // Play scene music & SFX
      if (scene.musicTrack) {
        audioEngine.startMusic(scene.musicTrack);
      }
      if (scene.sfx) {
        audioEngine.playSFX(scene.sfx);
      }

      // Speak dialogue if available (browser speech fallback)
      if (scene.dialogue && scene.dialogue.length > 0) {
        const line = scene.dialogue[0];
        audioEngine.speakDialogue(line.text, lang, line.characterId);
      }

      for (let frame = 0; frame < sceneFrames; frame++) {
        if (this.isCancelled) {
          mediaRecorder.stop();
          throw new Error('Rendering cancelled by user');
        }

        const sceneTime = frame * dt;
        globalTime += dt;

        // Clear canvas
        this.ctx.clearRect(0, 0, width, height);

        // A. Draw Background
        renderBackground(this.ctx, scene.backgroundId, width, height, sceneTime, scene.camera);

        // B. Draw Characters (sorted by zIndex)
        const sortedChars = [...(scene.characters || [])].sort((a, b) => a.zIndex - b.zIndex);
        for (const char of sortedChars) {
          const cx = (char.x / 100) * width;
          const cy = (char.y / 100) * height;
          const charScale = char.scale || 1.0;
          const expression = scene.dialogue?.[0]?.expression || 'happy';

          renderCharacterRig(
            this.ctx,
            char.characterId,
            char.action,
            expression,
            sceneTime,
            cx,
            cy,
            charScale,
            char.flipX
          );
        }

        // C. Draw Subtitles
        if (scene.subtitlesEnabled !== false) {
          this.drawSubtitles(scene, sceneTime, width, height, lang);
        }

        // D. Scene Transition Overlay (e.g. fade in at start, fade out at end)
        this.drawTransition(scene.transition, frame, sceneFrames, width, height);

        // Frame timing throttle for MediaRecorder
        await new Promise((r) => setTimeout(r, Math.floor(1000 / fps)));

        // Update progress
        const overallProgress = Math.min(
          90,
          Math.floor(25 + ((globalTime / totalDuration) * 65))
        );
        onProgress?.({
          stage: 'rendering_frames',
          progress: overallProgress,
          messageEn: `Rendering frame ${Math.floor(globalTime * fps)} of ${Math.floor(totalDuration * fps)}...`,
          messageAr: `معالجة اللقطة ${Math.floor(globalTime * fps)} من ${Math.floor(totalDuration * fps)}...`,
        });
      }
    }

    audioEngine.stopAll();

    onProgress?.({
      stage: 'assembling_stream',
      progress: 92,
      messageEn: 'Finalizing video stream and encoding audio tracks...',
      messageAr: 'تجميع المسارات وتشفير الصوت والصورة...',
    });

    mediaRecorder.stop();
    const rawBlob = await recordingPromise;

    onProgress?.({
      stage: 'finalizing',
      progress: 96,
      messageEn: 'Transcoding and saving permanent MP4 on server...',
      messageAr: 'معالجة وتثبيت ملف MP4 الدائم على الخادم...',
    });

    let format: 'mp4' | 'webm' = 'webm';
    let streamUrl = '';
    let downloadUrl = '';
    let finalBlob = rawBlob;

    // Upload raw WebM stream to server for persistent storage and FFmpeg H.264 MP4 conversion
    if (projectId) {
      try {
        const uploadRes = await fetch(`/api/videos/${projectId}/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'video/webm' },
          body: rawBlob,
        });

        if (uploadRes.ok) {
          const uploadData = await uploadRes.json();
          streamUrl = uploadData.streamUrl || `/api/videos/${projectId}/view`;
          downloadUrl = uploadData.downloadUrl || `/api/videos/${projectId}/download`;
          format = 'mp4';
        }
      } catch (uploadErr) {
        console.warn('[Pipeline] Server upload failed, falling back to local blob:', uploadErr);
      }
    }

    let createdBlobUrl: string | null = null;

    // Fallback URL only if server upload was skipped or failed
    if (!streamUrl) {
      createdBlobUrl = URL.createObjectURL(finalBlob);
      streamUrl = createdBlobUrl;
      downloadUrl = createdBlobUrl;
    }

    onProgress?.({
      stage: 'finalizing',
      progress: 100,
      messageEn: 'Video creation complete! Ready to preview & download.',
      messageAr: 'تم إنتاج الفيديو بنجاح! جاهز للمعاينة والتحميل.',
    });

    return {
      blob: finalBlob,
      videoUrl: streamUrl,
      downloadUrl,
      streamUrl,
      durationSeconds: totalDuration,
      width,
      height,
      format,
    };
  }

  private drawSubtitles(
    scene: Scene,
    sceneTime: number,
    width: number,
    height: number,
    lang: VideoLanguage
  ) {
    let captionText = scene.narration;
    if (scene.dialogue && scene.dialogue.length > 0) {
      const d = scene.dialogue[0];
      captionText = `${d.speakerName}: ${d.text}`;
    }

    if (!captionText) return;

    this.ctx.save();
    const isAr = lang === 'ar';
    const fontSize = Math.max(16, Math.floor(width * 0.028));
    this.ctx.font = `bold ${fontSize}px ${isAr ? 'Tajawal' : 'Plus Jakarta Sans'}, sans-serif`;
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';

    const textMetrics = this.ctx.measureText(captionText);
    const boxW = Math.min(width * 0.9, textMetrics.width + 40);
    const boxH = fontSize * 1.9;
    const boxX = (width - boxW) / 2;
    const boxY = height - boxH - (height * 0.06);

    // Semi-transparent pill background
    this.ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    this.ctx.beginPath();
    this.ctx.roundRect(boxX, boxY, boxW, boxH, 12);
    this.ctx.fill();

    // Subtle gradient outline
    this.ctx.strokeStyle = 'rgba(168, 85, 247, 0.6)';
    this.ctx.lineWidth = 2;
    this.ctx.stroke();

    // High-contrast text
    this.ctx.fillStyle = '#ffffff';
    this.ctx.fillText(captionText, width / 2, boxY + boxH / 2);
    this.ctx.restore();
  }

  private drawTransition(
    transition: string,
    frame: number,
    totalFrames: number,
    width: number,
    height: number
  ) {
    const fadeFrames = 8;
    if (transition === 'fade') {
      if (frame < fadeFrames) {
        const alpha = 1 - (frame / fadeFrames);
        this.ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
        this.ctx.fillRect(0, 0, width, height);
      } else if (frame > totalFrames - fadeFrames) {
        const alpha = (frame - (totalFrames - fadeFrames)) / fadeFrames;
        this.ctx.fillStyle = `rgba(0, 0, 0, ${alpha})`;
        this.ctx.fillRect(0, 0, width, height);
      }
    }
  }
}
