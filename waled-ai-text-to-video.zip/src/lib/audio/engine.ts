import { SFXType, MusicTrackType, CharacterId } from '../../types';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private musicGainNode: GainNode | null = null;
  private sfxGainNode: GainNode | null = null;
  private voiceGainNode: GainNode | null = null;
  private currentMusicOscillators: (OscillatorNode | AudioBufferSourceNode)[] = [];
  private mediaStreamDestination: MediaStreamAudioDestinationNode | null = null;
  private isMusicPlaying = false;

  public init() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();

      this.musicGainNode = this.ctx.createGain();
      this.sfxGainNode = this.ctx.createGain();
      this.voiceGainNode = this.ctx.createGain();

      this.musicGainNode.gain.value = 0.25;
      this.sfxGainNode.gain.value = 0.6;
      this.voiceGainNode.gain.value = 0.9;

      // Master media stream destination for canvas recorder
      this.mediaStreamDestination = this.ctx.createMediaStreamDestination();

      // Connect to speakers
      this.musicGainNode.connect(this.ctx.destination);
      this.sfxGainNode.connect(this.ctx.destination);
      this.voiceGainNode.connect(this.ctx.destination);

      // Connect also to recorder destination
      this.musicGainNode.connect(this.mediaStreamDestination);
      this.sfxGainNode.connect(this.mediaStreamDestination);
      this.voiceGainNode.connect(this.mediaStreamDestination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getAudioStream(): MediaStream | null {
    if (!this.mediaStreamDestination) {
      this.init();
    }
    return this.mediaStreamDestination ? this.mediaStreamDestination.stream : null;
  }

  // ---------------------------------------------------------------------------
  // PROCEDURAL SOUND EFFECTS (SFX)
  // ---------------------------------------------------------------------------
  public playSFX(type: SFXType) {
    if (type === 'none') return;
    this.init();
    if (!this.ctx || !this.sfxGainNode) return;

    const t = this.ctx.currentTime;

    switch (type) {
      case 'pop': {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(650, t);
        osc.frequency.exponentialRampToValueAtTime(140, t + 0.08);

        gain.gain.setValueAtTime(0.8, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.08);

        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.09);
        break;
      }

      case 'boing': {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(200, t);
        osc.frequency.linearRampToValueAtTime(540, t + 0.15);
        osc.frequency.exponentialRampToValueAtTime(180, t + 0.35);

        gain.gain.setValueAtTime(0.7, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.35);

        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.36);
        break;
      }

      case 'whoosh': {
        // Noise buffer sweep
        const bufferSize = this.ctx.sampleRate * 0.3;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(250, t);
        filter.frequency.exponentialRampToValueAtTime(1800, t + 0.15);
        filter.frequency.exponentialRampToValueAtTime(300, t + 0.3);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.01, t);
        gain.gain.linearRampToValueAtTime(0.7, t + 0.12);
        gain.gain.linearRampToValueAtTime(0.01, t + 0.3);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGainNode);
        noise.start(t);
        noise.stop(t + 0.31);
        break;
      }

      case 'cheer': {
        // Celebration chime flourish
        const freqs = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
        freqs.forEach((freq, idx) => {
          const osc = this.ctx!.createOscillator();
          const gain = this.ctx!.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, t + idx * 0.05);

          gain.gain.setValueAtTime(0.4, t + idx * 0.05);
          gain.gain.exponentialRampToValueAtTime(0.01, t + 0.6);

          osc.connect(gain);
          gain.connect(this.sfxGainNode!);
          osc.start(t + idx * 0.05);
          osc.stop(t + 0.65);
        });
        break;
      }

      case 'laugh': {
        // Silly bounce notes
        for (let i = 0; i < 4; i++) {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = 'triangle';
          const startTime = t + i * 0.09;
          osc.frequency.setValueAtTime(i % 2 === 0 ? 440 : 554, startTime);
          gain.gain.setValueAtTime(0.5, startTime);
          gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.07);

          osc.connect(gain);
          gain.connect(this.sfxGainNode);
          osc.start(startTime);
          osc.stop(startTime + 0.08);
        }
        break;
      }

      case 'footsteps': {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(110, t);
        osc.frequency.exponentialRampToValueAtTime(50, t + 0.08);

        gain.gain.setValueAtTime(0.6, t);
        gain.gain.exponentialRampToValueAtTime(0.01, t + 0.08);

        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.09);
        break;
      }

      case 'bell': {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, t);

        gain.gain.setValueAtTime(0.8, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

        osc.connect(gain);
        gain.connect(this.sfxGainNode);
        osc.start(t);
        osc.stop(t + 0.85);
        break;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // BACKGROUND MUSIC LOOPS
  // ---------------------------------------------------------------------------
  public startMusic(track: MusicTrackType) {
    if (track === 'none') {
      this.stopMusic();
      return;
    }
    this.stopMusic();
    this.init();
    if (!this.ctx || !this.musicGainNode) return;

    this.isMusicPlaying = true;
    this.scheduleMusicNotes(track);
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    for (const osc of this.currentMusicOscillators) {
      try {
        osc.stop();
        osc.disconnect();
      } catch (e) {
        // Ignored
      }
    }
    this.currentMusicOscillators = [];
  }

  private scheduleMusicNotes(track: MusicTrackType) {
    if (!this.ctx || !this.musicGainNode || !this.isMusicPlaying) return;

    const t = this.ctx.currentTime;
    let notes: number[] = [];
    let speed = 0.3; // duration per beat

    if (track === 'playful_adventure') {
      // C, E, G, A, C5 arpeggios
      notes = [261.63, 329.63, 392.0, 440.0, 523.25, 392.0, 329.63, 261.63];
      speed = 0.22;
    } else if (track === 'whimsical_story') {
      // G Major soft chord notes
      notes = [392.0, 440.0, 493.88, 587.33, 523.25, 493.88, 440.0, 392.0];
      speed = 0.35;
    } else if (track === 'upbeat_groove') {
      // A Minor energetic bass
      notes = [220.0, 261.63, 293.66, 329.63, 349.23, 329.63, 293.66, 220.0];
      speed = 0.2;
    }

    const totalDuration = notes.length * speed;

    notes.forEach((freq, i) => {
      if (!this.ctx || !this.musicGainNode) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + i * speed);

      gain.gain.setValueAtTime(0.08, t + i * speed);
      gain.gain.exponentialRampToValueAtTime(0.005, t + (i + 1) * speed - 0.02);

      osc.connect(gain);
      gain.connect(this.musicGainNode);
      osc.start(t + i * speed);
      osc.stop(t + (i + 1) * speed);

      this.currentMusicOscillators.push(osc);
    });

    // Schedule next loop
    if (this.isMusicPlaying) {
      setTimeout(() => {
        if (this.isMusicPlaying) {
          this.scheduleMusicNotes(track);
        }
      }, totalDuration * 1000 - 50);
    }
  }

  // ---------------------------------------------------------------------------
  // SPEECH / DIALOGUE VOICE SYNTHESIS
  // ---------------------------------------------------------------------------
  public speakDialogue(
    text: string,
    lang: 'ar' | 'en',
    characterId?: CharacterId,
    onEnd?: () => void
  ) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'ar' ? 'ar-SA' : 'en-US';

    // Character pitch and rate personalization
    if (characterId === 'bader_rabbit') {
      utterance.pitch = 1.35; // high, energetic
      utterance.rate = 1.1;
    } else if (characterId === 'faris_bear') {
      utterance.pitch = 0.75; // deep, warm
      utterance.rate = 0.95;
    } else if (characterId === 'maymoun_monkey') {
      utterance.pitch = 1.45; // cheeky, rapid
      utterance.rate = 1.15;
    } else if (characterId === 'salma_explorer') {
      utterance.pitch = 1.1; // crisp, clear
      utterance.rate = 1.05;
    } else if (characterId === 'robo_z') {
      utterance.pitch = 0.9;
      utterance.rate = 1.0;
    }

    // Voice selection fallback
    const voices = window.speechSynthesis.getVoices();
    const targetPrefix = lang === 'ar' ? 'ar' : 'en';
    const matchedVoice = voices.find((v) => v.lang.toLowerCase().startsWith(targetPrefix));
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onend = () => {
      if (onEnd) onEnd();
    };

    utterance.onerror = () => {
      if (onEnd) onEnd();
    };

    window.speechSynthesis.speak(utterance);
  }

  public stopAll() {
    this.stopMusic();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
}

export const audioEngine = new AudioEngine();
