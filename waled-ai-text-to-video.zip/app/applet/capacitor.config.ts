import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.waleed.ai',
  appName: 'Waleed AI',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
