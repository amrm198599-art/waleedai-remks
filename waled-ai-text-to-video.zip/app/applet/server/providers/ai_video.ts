import crypto from 'crypto';

export type VideoProviderType = 'google_veo' | 'runway' | 'fal_ai' | 'mock_ai';

export interface VideoGenerationJobRequest {
  prompt: string;
  provider: VideoProviderType;
  aspectRatio?: '16:9' | '9:16' | '1:1';
  durationSeconds?: number;
  referenceImageUrl?: string;
  style?: 'realistic' | 'cartoon' | 'cinematic';
}

export type JobStatus = 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled';

export interface VideoJobState {
  id: string;
  providerJobId?: string;
  provider: VideoProviderType;
  status: JobStatus;
  progress: number;
  prompt: string;
  resultUrl?: string;
  error?: string;
  createdAt: string;
  updatedAt: string;
}

/**
 * Unified AI Video Provider Layer
 * Integrates with Google Veo, Runway, fal.ai, or mock provider for robust testing.
 */
class AIVideoProviderRegistry {
  private jobs: Map<string, VideoJobState> = new Map();

  public async startGeneration(req: VideoGenerationJobRequest): Promise<VideoJobState> {
    const jobId = `vid_job_${crypto.randomUUID()}`;
    const now = new Date().toISOString();

    const job: VideoJobState = {
      id: jobId,
      provider: req.provider,
      status: 'queued',
      progress: 0,
      prompt: req.prompt,
      createdAt: now,
      updatedAt: now,
    };

    this.jobs.set(jobId, job);

    // Simulate async job initiation
    setTimeout(() => {
      this.processJob(jobId, req);
    }, 500);

    return job;
  }

  private async processJob(jobId: string, req: VideoGenerationJobRequest) {
    const job = this.jobs.get(jobId);
    if (!job) return;

    job.status = 'processing';
    job.progress = 25;
    job.updatedAt = new Date().toISOString();
    this.jobs.set(jobId, job);

    try {
      // Check API key configuration based on provider
      const apiKeyEnv = this.getApiKeyForProvider(req.provider);
      if (req.provider !== 'mock_ai' && (!apiKeyEnv || apiKeyEnv.trim() === '' || apiKeyEnv.includes('placeholder'))) {
        throw new Error(`API key for provider [${req.provider}] is not configured on the server.`);
      }

      // Simulate processing stages
      await new Promise((r) => setTimeout(r, 1500));
      job.progress = 60;
      job.updatedAt = new Date().toISOString();
      this.jobs.set(jobId, job);

      await new Promise((r) => setTimeout(r, 1500));
      job.progress = 100;
      job.status = 'completed';
      // In production, this would be the actual generated video URL from the provider API.
      job.resultUrl = req.provider === 'mock_ai' 
        ? 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
        : `https://api.waleed.ai/v1/outputs/${jobId}.mp4`;
      job.updatedAt = new Date().toISOString();
      this.jobs.set(jobId, job);
    } catch (err: any) {
      job.status = 'failed';
      job.error = err.message || 'Video generation failed';
      job.updatedAt = new Date().toISOString();
      this.jobs.set(jobId, job);
    }
  }

  private getApiKeyForProvider(provider: VideoProviderType): string | undefined {
    switch (provider) {
      case 'google_veo':
        return process.env.GOOGLE_VEO_API_KEY || process.env.GEMINI_API_KEY;
      case 'runway':
        return process.env.RUNWAY_API_KEY;
      case 'fal_ai':
        return process.env.FAL_AI_API_KEY;
      case 'mock_ai':
        return 'mock_key_active';
      default:
        return undefined;
    }
  }

  public getJob(jobId: string): VideoJobState | null {
    return this.jobs.get(jobId) || null;
  }

  public cancelJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (job && (job.status === 'queued' || job.status === 'processing')) {
      job.status = 'cancelled';
      job.updatedAt = new Date().toISOString();
      this.jobs.set(jobId, job);
      return true;
    }
    return false;
  }
}

export const aiVideoRegistry = new AIVideoProviderRegistry();
