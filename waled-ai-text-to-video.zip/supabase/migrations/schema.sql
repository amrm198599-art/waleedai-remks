-- ============================================================================
-- Waled AI — Complete AI Video Creation Platform
-- Database Schema & Security Migrations
-- Target: PostgreSQL 14+ / Supabase
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    display_name TEXT NOT NULL DEFAULT 'Creator',
    preferred_language VARCHAR(5) NOT NULL DEFAULT 'ar' CHECK (preferred_language IN ('ar', 'en')),
    avatar_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 2. USER SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.user_settings (
    user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
    preferred_language VARCHAR(5) NOT NULL DEFAULT 'ar' CHECK (preferred_language IN ('ar', 'en')),
    preferred_theme VARCHAR(10) NOT NULL DEFAULT 'dark' CHECK (preferred_theme IN ('light', 'dark', 'system')),
    default_voice VARCHAR(50) NOT NULL DEFAULT 'bader_arabic',
    default_aspect_ratio VARCHAR(10) NOT NULL DEFAULT '16:9' CHECK (default_aspect_ratio IN ('16:9', '9:16', '1:1')),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 3. PROJECTS TABLE
CREATE TABLE IF NOT EXISTS public.projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    language VARCHAR(5) NOT NULL DEFAULT 'ar' CHECK (language IN ('ar', 'en')),
    aspect_ratio VARCHAR(10) NOT NULL DEFAULT '16:9' CHECK (aspect_ratio IN ('16:9', '9:16', '1:1')),
    project_status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (project_status IN ('draft', 'rendering', 'completed', 'failed')),
    video_style VARCHAR(50) NOT NULL DEFAULT 'cartoon' CHECK (video_style IN ('cartoon', 'storyboard_media', 'motion_comic')),
    script_json JSONB NOT NULL DEFAULT '{"scenes": []}'::jsonb,
    thumbnail_url TEXT,
    rendered_video_url TEXT,
    duration_seconds NUMERIC(6,2) NOT NULL DEFAULT 0.0 CHECK (duration_seconds >= 0 AND duration_seconds <= 120),
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- 4. SCENES TABLE
CREATE TABLE IF NOT EXISTS public.scenes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    scene_order INT NOT NULL CHECK (scene_order >= 0),
    duration_seconds NUMERIC(5,2) NOT NULL DEFAULT 5.0 CHECK (duration_seconds > 0 AND duration_seconds <= 30),
    narration TEXT,
    dialogue_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    character_assignments JSONB NOT NULL DEFAULT '[]'::jsonb,
    background_id VARCHAR(100) NOT NULL DEFAULT 'forest_clearing',
    animation_json JSONB NOT NULL DEFAULT '{"actions": [], "camera": "static"}'::jsonb,
    subtitle_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    audio_metadata JSONB NOT NULL DEFAULT '{"musicTrack": "playful_acoustic", "musicVolume": 0.3, "sfx": []}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    UNIQUE(project_id, scene_order)
);

-- 5. GENERATION JOBS TABLE
CREATE TABLE IF NOT EXISTS public.generation_jobs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'validating_assets', 'synthesizing_audio', 'rendering_frames', 'assembling_stream', 'completed', 'failed', 'cancelled')),
    progress INT NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    idempotency_key VARCHAR(128) UNIQUE NOT NULL,
    output_video_url TEXT,
    output_format VARCHAR(10) NOT NULL DEFAULT 'mp4',
    error_code VARCHAR(50),
    error_message TEXT,
    logs JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

-- 6. QUOTA RESERVATIONS TABLE (Atomic 24-hour rolling window policy)
CREATE TABLE IF NOT EXISTS public.quota_reservations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    job_id UUID NOT NULL REFERENCES public.generation_jobs(id) ON DELETE CASCADE,
    reserved_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now()),
    reservation_status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (reservation_status IN ('active', 'consumed', 'released')),
    released_at TIMESTAMPTZ,
    release_reason TEXT
);

-- 7. MEDIA ASSETS TABLE
CREATE TABLE IF NOT EXISTS public.media_assets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
    asset_type VARCHAR(50) NOT NULL CHECK (asset_type IN ('character', 'background', 'prop', 'audio_music', 'audio_sfx', 'voice')),
    storage_path TEXT NOT NULL,
    title VARCHAR(150) NOT NULL,
    metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    license_name VARCHAR(100) NOT NULL DEFAULT 'CC0_Public_Domain',
    attribution_text TEXT NOT NULL DEFAULT 'Waled AI Curated Library',
    is_public BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT timezone('utc'::text, now())
);

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON public.projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_updated_at ON public.projects(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_scenes_project_order ON public.scenes(project_id, scene_order);
CREATE INDEX IF NOT EXISTS idx_jobs_user_status ON public.generation_jobs(user_id, status);
CREATE INDEX IF NOT EXISTS idx_quota_user_active ON public.quota_reservations(user_id, reserved_at) WHERE reservation_status IN ('active', 'consumed');
CREATE INDEX IF NOT EXISTS idx_media_assets_type ON public.media_assets(asset_type, is_public);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scenes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generation_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quota_reservations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.media_assets ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can view and update their own profile
CREATE POLICY "Users can read own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- User Settings: Users can read and write their own settings
CREATE POLICY "Users can read own settings" ON public.user_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own settings" ON public.user_settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own settings" ON public.user_settings FOR UPDATE USING (auth.uid() = user_id);

-- Projects: Full access to own projects
CREATE POLICY "Users can read own projects" ON public.projects FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own projects" ON public.projects FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own projects" ON public.projects FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own projects" ON public.projects FOR DELETE USING (auth.uid() = user_id);

-- Scenes: Access restricted through project ownership
CREATE POLICY "Users can access scenes of own projects" ON public.scenes FOR ALL USING (
    EXISTS (SELECT 1 FROM public.projects WHERE projects.id = scenes.project_id AND projects.user_id = auth.uid())
);

-- Generation Jobs: Users can view their own jobs
CREATE POLICY "Users can read own jobs" ON public.generation_jobs FOR SELECT USING (auth.uid() = user_id);

-- Quota Reservations: Users can read their own quota records
CREATE POLICY "Users can read own quota reservations" ON public.quota_reservations FOR SELECT USING (auth.uid() = user_id);

-- Media Assets: Users can read public assets or their own private uploads
CREATE POLICY "Users can read public or own assets" ON public.media_assets FOR SELECT USING (is_public = true OR auth.uid() = owner_id);
CREATE POLICY "Users can insert own assets" ON public.media_assets FOR INSERT WITH CHECK (auth.uid() = owner_id);

-- ============================================================================
-- ATOMIC QUOTA RESERVATION FUNCTION (Rolling 24-hour Window)
-- Max 2 active/consumed jobs per 24 hours.
-- ============================================================================
CREATE OR REPLACE FUNCTION public.reserve_video_quota(
    p_user_id UUID,
    p_job_id UUID,
    p_max_jobs_per_day INT DEFAULT 2
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_active_count INT;
    v_oldest_timestamp TIMESTAMPTZ;
    v_reset_seconds INT;
    v_reservation_id UUID;
BEGIN
    -- Acquire exclusive transaction lock on the user's quota scope to prevent race conditions
    PERFORM pg_advisory_xact_lock(hashtext('quota_' || p_user_id::text));

    -- Count jobs reserved in the last 24 hours that are either active or consumed
    SELECT COUNT(*), MIN(reserved_at)
    INTO v_active_count, v_oldest_timestamp
    FROM public.quota_reservations
    WHERE user_id = p_user_id
      AND reservation_status IN ('active', 'consumed')
      AND reserved_at >= (now() - INTERVAL '24 hours');

    -- Check if user exceeds allowance
    IF v_active_count >= p_max_jobs_per_day THEN
        v_reset_seconds := GREATEST(0, EXTRACT(EPOCH FROM (v_oldest_timestamp + INTERVAL '24 hours' - now()))::INT);
        RETURN jsonb_build_object(
            'success', false,
            'error_code', 'QUOTA_EXCEEDED',
            'message', 'Daily quota limit of 2 video generations reached. Please wait until quota resets.',
            'used_count', v_active_count,
            'max_allowed', p_max_jobs_per_day,
            'reset_in_seconds', v_reset_seconds
        );
    END IF;

    -- Reserve slot atomically
    INSERT INTO public.quota_reservations (user_id, job_id, reserved_at, reservation_status)
    VALUES (p_user_id, p_job_id, now(), 'active')
    RETURNING id INTO v_reservation_id;

    RETURN jsonb_build_object(
        'success', true,
        'reservation_id', v_reservation_id,
        'used_count', v_active_count + 1,
        'remaining_allowance', p_max_jobs_per_day - (v_active_count + 1),
        'max_allowed', p_max_jobs_per_day
    );
END;
$$;
